/**
 * اسکریپت اسکن گوگل درایو برای کرکس صورتی
 * این اسکریپت را در کنسول مرورگر درایو اجرا کنید
 */

(function() {
    console.log('🦅 کرکس صورتی - اسکنر درایو فعال شد');
    
    // تابع اصلی اسکن
    function scanDriveContent() {
        const results = {};
        
        // نقشه‌برداری نام پوشه‌ها
        const folderMap = {
            'ریاضی': ['math', 'mathematics', 'riazi', 'ریاضی'],
            'فیزیک': ['physics', 'fizik', 'فیزیک'],
            'شیمی': ['chemistry', 'shimi', 'شیمی'],
            'زیست‌شناسی': ['biology', 'zist', 'زیست', 'زیست‌شناسی'],
            'ادبیات فارسی': ['persian', 'literature', 'adabiyat', 'ادبیات', 'ادبیات فارسی'],
            'انگلیسی': ['english', 'انگلیسی'],
            'کامپیوتر': ['computer', 'cs', 'کامپیوتر'],
            'جبر': ['algebra', 'jabr', 'جبر'],
            'المپیاد نجوم': ['astronomy', 'olympiad-astronomy', 'نجوم', 'المپیاد نجوم'],
            'المپیاد فیزیک': ['olympiad-physics', 'المپیاد فیزیک'],
            'المپیاد ریاضی': ['olympiad-math', 'المپیاد ریاضی'],
            'المپیاد کامپیوتر': ['olympiad-computer', 'المپیاد کامپیوتر']
        };
        
        // جستجوی عناصر فایل/پوشه در DOM
        const fileElements = document.querySelectorAll('[data-target="file"]');
        
        fileElements.forEach(element => {
            const fileName = element.getAttribute('aria-label') || element.textContent || '';
            const lowerName = fileName.toLowerCase();
            
            // تشخیص نوع درس بر اساس نام فایل/پوشه
            for (const [subject, keywords] of Object.entries(folderMap)) {
                if (keywords.some(keyword => lowerName.includes(keyword))) {
                    results[subject] = (results[subject] || 0) + 1;
                    break;
                }
            }
        });
        
        return results;
    }
    
    // تابع تولید خروجی قابل کپی
    function generateOutput(results) {
        let output = '📊 نتایج اسکن درایو:\n';
        output += '=' + '='.repeat(30) + '\n\n';
        
        if (Object.keys(results).length === 0) {
            output += '❌ هیچ فایل درسی یافت نشد\n';
            output += '💡 اطمینان حاصل کنید که در پوشه صحیح هستید\n';
        } else {
            output += '📝 فرمت کپی برای کرکس صورتی:\n';
            output += '-'.repeat(40) + '\n';
            
            Object.entries(results)
                .sort(([,a], [,b]) => b - a)
                .forEach(([subject, count]) => {
                    output += `${subject}: ${count}\n`;
                });
            
            output += '-'.repeat(40) + '\n';
            output += `📈 مجموع: ${Object.values(results).reduce((a, b) => a + b, 0)} فایل\n`;
            output += `📚 دروس: ${Object.keys(results).length} عدد\n`;
        }
        
        output += '\n🔄 برای اسکن مجدد: scanDrive()\n';
        output += '📋 برای کپی نتایج: copyResults()\n';
        
        return output;
    }
    
    // تابع کپی نتایج به کلیپبورد
    function copyResults() {
        const results = scanDriveContent();
        const copyText = Object.entries(results)
            .map(([subject, count]) => `${subject}: ${count}`)
            .join('\n');
        
        navigator.clipboard.writeText(copyText).then(() => {
            console.log('✅ نتایج در کلیپبورد کپی شد');
        }).catch(() => {
            console.log('❌ خطا در کپی کردن');
            console.log('📋 نتایج:\n' + copyText);
        });
    }
    
    // تابع اصلی
    function scanDrive() {
        console.clear();
        console.log('🔍 در حال اسکن...');
        
        setTimeout(() => {
            const results = scanDriveContent();
            const output = generateOutput(results);
            console.log(output);
            
            // ذخیره در متغیر سراسری
            window.driveResults = results;
        }, 1000);
    }
    
    // تعریف توابع سراسری
    window.scanDrive = scanDrive;
    window.copyResults = copyResults;
    
    // اجرای اولیه
    scanDrive();
    
    console.log('');
    console.log('🎯 دستورات موجود:');
    console.log('  scanDrive() - اسکن مجدد');
    console.log('  copyResults() - کپی نتایج');
    console.log('');
    
})();

// راهنمای نصب
console.log('📖 راهنمای استفاده:');
console.log('1. به گوگل درایو بروید');
console.log('2. پوشه اصلی جزوه‌ها را باز کنید');
console.log('3. کنسول مرورگر را باز کنید (F12)');
console.log('4. این کد را paste کنید و Enter بزنید');
console.log('5. نتایج را کپی کرده و در اپلیکیشن paste کنید');