import { useState, useMemo, useEffect } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { LanguageProvider, useLanguage } from './components/LanguageProvider';
import { Header } from './components/Header';
import { MainMenu } from './components/MainMenu';
import { SubjectSelectionPage } from './components/SubjectSelectionPage';
import { CSVNotebooksPage } from './components/CSVNotebooksPage';
import { SchedulePlanner } from './components/SchedulePlanner';

type AppView = 'menu' | 'notebooks' | 'scheduler';

interface CSVRow {
  file_name: string;
  subject: string;
  drive_link: string;
}

interface ProcessedData {
  [subject: string]: CSVRow[];
}

function AppContent() {
  const [currentView, setCurrentView] = useState<AppView>('menu');
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [csvData, setCsvData] = useState<ProcessedData>({});
  const [loading, setLoading] = useState(false);
  const { language } = useLanguage();

  // تابع خواندن CSV
  const fetchCSVData = async () => {
    setLoading(true);
    try {
      let csvText = '';
      
      try {
        const csvUrl = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vTfsVcK1hkQG09BaccQxrToa21kMx0q2PmDxRvIbALC8F4Ub0EvA4x4gm5qaG49SD74UCKfa8vmF96n/pub?output=csv';
        const response = await fetch(csvUrl);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        csvText = await response.text();
        console.log('📄 CSV خام:', csvText);
      } catch (fetchError) {
        console.error('Could not fetch from Google Sheets:', fetchError);
        
        // پیام راهنما برای کاربر
        alert(
          language === 'fa'
            ? '⚠️ خطا در بارگذاری Google Sheet\n\n' +
              'لطفاً مطمئن شوید که:\n' +
              '1. Google Sheet شما Publish to web شده باشد\n' +
              '2. لینک صحیح است'
            : '⚠️ Error loading Google Sheet\n\n' +
              'Please make sure:\n' +
              '1. Your Google Sheet is published to web\n' +
              '2. The link is correct'
        );
        
        setLoading(false);
        return;
      }
      
      const rows = csvText.split('\n').filter(row => row.trim());
      if (rows.length <= 1) {
        console.warn('CSV خالی است');
        alert(language === 'fa' ? 'CSV خالی است!' : 'CSV is empty!');
        setLoading(false);
        return;
      }

      const processedData: ProcessedData = {};

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i].trim();
        if (!row) continue;
        
        const columns = parseCSVRow(row);
        
        if (columns.length >= 3) {
          const csvRow: CSVRow = {
            file_name: columns[0]?.trim() || '',    // FileName
            drive_link: columns[1]?.trim() || '',   // FileId (لینک درایو)
            subject: columns[2]?.trim() || ''       // Subject (اسم درس)
          };

          // استفاده مستقیم از Subject (ستون سوم)
          const subjectName = csvRow.subject;

          if (subjectName && csvRow.drive_link && csvRow.file_name) {
            if (!processedData[subjectName]) {
              processedData[subjectName] = [];
            }
            processedData[subjectName].push(csvRow);
          }
        }
      }

      setCsvData(processedData);
      console.log('✅ داده‌ها با موفقیت بارگذاری شد:', processedData);
      console.log('📚 موضوعات موجود:', Object.keys(processedData));
      
      // نمایش تعداد جزوه‌های هر درس
      Object.keys(processedData).forEach(subject => {
        console.log(`📖 ${subject}: ${processedData[subject].length} جزوه`);
      });
    } catch (err) {
      console.error('Error processing CSV data:', err);
    } finally {
      setLoading(false);
    }
  };

  // تابع تجزیه CSV
  const parseCSVRow = (row: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < row.length; i++) {
      const char = row[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current);
    return result.map(col => col.replace(/"/g, ''));
  };

  // خواندن CSV در شروع
  useEffect(() => {
    fetchCSVData();
  }, []);

  // ایجاد لیست موضوعات از CSV
  const availableSubjects = useMemo(() => {
    return Object.keys(csvData).map(subject => ({
      id: subject,
      name: subject,
      nameEn: subject,
      icon: '📚',
      notebookCount: csvData[subject]?.length || 0
    }));
  }, [csvData]);

  const goBackToSubjects = () => {
    setSelectedSubject(null);
  };

  const goBackToMenu = () => {
    setCurrentView('menu');
    setSelectedSubject(null);
  };

  const handleSelectNotebooks = () => {
    setCurrentView('notebooks');
  };

  const handleSelectScheduler = () => {
    setCurrentView('scheduler');
  };
  
  const showBackButton = currentView !== 'menu' || !!selectedSubject;
  const getBackAction = () => {
    if (selectedSubject) return goBackToSubjects;
    if (currentView !== 'menu') return goBackToMenu;
    return undefined;
  };

  const currentSubjectName = selectedSubject || '';

  return (
    <div 
      className="min-h-screen relative"
      dir={language === 'fa' ? 'rtl' : 'ltr'}
    >
      {/* Pink Vulture Background */}
      <div 
        className="fixed inset-0 z-0"
        style={{
          backgroundImage: `url(https://images.unsplash.com/photo-1751555082580-c155a8c83322?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5rJTIwZWFnbGUlMjBiaXJkfGVufDF8fHx8MTc1NzUwNzQ3NHww&ixlib=rb-4.0&q=80&w=1080)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          opacity: 0.15
        }}
      />
      
      {/* Gradient overlay for better readability */}
      <div className="fixed inset-0 z-0 bg-gradient-to-br from-pink-900/20 via-transparent to-amber-900/20" />
      
      {/* Content overlay */}
      <div className="relative z-10 min-h-screen bg-background/85 backdrop-blur-sm">
        <Header 
          showBackButton={showBackButton}
          onBack={getBackAction()}
          subjectName={currentSubjectName}
          onRefresh={fetchCSVData}
        />
        
        <main className="container mx-auto px-4 py-8">
          {currentView === 'menu' && !selectedSubject && (
            <MainMenu
              onSelectNotebooks={handleSelectNotebooks}
              onSelectScheduler={handleSelectScheduler}
            />
          )}
          
          {currentView === 'notebooks' && !selectedSubject && (
            <SubjectSelectionPage
              subjects={availableSubjects}
              onSelectSubject={setSelectedSubject}
              loading={loading}
              onRefresh={fetchCSVData}
            />
          )}
          
          {currentView === 'notebooks' && selectedSubject && (
            <CSVNotebooksPage
              subjectName={selectedSubject}
              csvData={csvData}
            />
          )}
          
          {currentView === 'scheduler' && (
            <SchedulePlanner />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </ThemeProvider>
  );
}