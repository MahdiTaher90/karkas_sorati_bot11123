import { useState } from 'react';
import { useLanguage } from './LanguageProvider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { List, Save, RotateCcw, CheckCircle } from 'lucide-react';
import { contentConfig, updateAvailableNotebooks } from '../data/contentConfig';

export function BulkContentManager() {
  const { language } = useLanguage();
  const [editedConfig, setEditedConfig] = useState(() => {
    const config: Record<string, { count: number; enabled: boolean }> = {};
    Object.entries(contentConfig).forEach(([subject, status]) => {
      config[subject] = {
        count: status.availableNotebooks,
        enabled: status.enabled
      };
    });
    return config;
  });

  const hasChanges = () => {
    return Object.entries(editedConfig).some(([subject, edited]) => {
      const original = contentConfig[subject];
      return original.availableNotebooks !== edited.count || original.enabled !== edited.enabled;
    });
  };

  const resetChanges = () => {
    const config: Record<string, { count: number; enabled: boolean }> = {};
    Object.entries(contentConfig).forEach(([subject, status]) => {
      config[subject] = {
        count: status.availableNotebooks,
        enabled: status.enabled
      };
    });
    setEditedConfig(config);
  };

  const applyChanges = () => {
    let changesCount = 0;
    
    Object.entries(editedConfig).forEach(([subject, edited]) => {
      const original = contentConfig[subject];
      
      if (original.availableNotebooks !== edited.count) {
        updateAvailableNotebooks(subject, edited.count);
        changesCount++;
      }
      
      if (original.enabled !== edited.enabled) {
        contentConfig[subject].enabled = edited.enabled;
        changesCount++;
      }
    });
    
    if (changesCount > 0) {
      console.log(`✅ ${changesCount} تغییر اعمال شد`);
      window.location.reload();
    }
  };

  const updateSubject = (subject: string, field: 'count' | 'enabled', value: any) => {
    setEditedConfig(prev => ({
      ...prev,
      [subject]: {
        ...prev[subject],
        [field]: value
      }
    }));
  };

  const quickSetAll = (count: number) => {
    const newConfig = { ...editedConfig };
    Object.keys(newConfig).forEach(subject => {
      newConfig[subject] = {
        ...newConfig[subject],
        count: count,
        enabled: count > 0
      };
    });
    setEditedConfig(newConfig);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <List className="h-4 w-4" />
          {language === 'fa' ? 'مدیریت گروهی' : 'Bulk Edit'}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <List className="h-5 w-5" />
            {language === 'fa' ? 'مدیریت گروهی محتوا' : 'Bulk Content Management'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* دکمه‌های سریع */}
          <Card>
            <CardHeader>
              <CardTitle>
                {language === 'fa' ? 'تنظیمات سریع' : 'Quick Actions'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={() => quickSetAll(0)}>
                  {language === 'fa' ? 'همه → 0' : 'All → 0'}
                </Button>
                <Button variant="outline" size="sm" onClick={() => quickSetAll(5)}>
                  {language === 'fa' ? 'همه → 5' : 'All → 5'}
                </Button>
                <Button variant="outline" size="sm" onClick={() => quickSetAll(10)}>
                  {language === 'fa' ? 'همه → 10' : 'All → 10'}
                </Button>
                <Button variant="outline" size="sm" onClick={() => quickSetAll(35)}>
                  {language === 'fa' ? 'همه → 35' : 'All → 35'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* لیست دروس */}
          <Card>
            <CardHeader>
              <CardTitle>
                {language === 'fa' ? 'دروس' : 'Subjects'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(contentConfig).map(([subject, status]) => {
                  const edited = editedConfig[subject];
                  const hasChanged = status.availableNotebooks !== edited.count || status.enabled !== edited.enabled;
                  
                  return (
                    <div 
                      key={subject}
                      className={`flex items-center justify-between p-4 border rounded-lg ${
                        hasChanged ? 'border-blue-300 bg-blue-50 dark:bg-blue-950' : ''
                      }`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          <div className="font-medium">{subject}</div>
                          {hasChanged && (
                            <Badge variant="secondary" className="text-xs">
                              {language === 'fa' ? 'تغییر یافته' : 'Modified'}
                            </Badge>
                          )}
                        </div>
                        {status.customMessage && (
                          <div className="text-xs text-muted-foreground mt-1">
                            {language === 'fa' ? status.customMessage.fa : status.customMessage.en}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {/* فعال/غیرفعال */}
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={edited.enabled}
                            onCheckedChange={(checked) => updateSubject(subject, 'enabled', checked)}
                          />
                          <Label className="text-sm">
                            {language === 'fa' ? 'فعال' : 'Active'}
                          </Label>
                        </div>
                        
                        {/* تعداد جزوه */}
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            min="0"
                            max="35"
                            value={edited.count}
                            onChange={(e) => updateSubject(subject, 'count', parseInt(e.target.value) || 0)}
                            className="w-20"
                          />
                          <span className="text-sm text-muted-foreground">/35</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* دکمه‌های اصلی */}
          <div className="flex gap-3">
            <Button 
              onClick={applyChanges} 
              disabled={!hasChanges()}
              className="flex-1"
            >
              <Save className="h-4 w-4 mr-2" />
              {language === 'fa' ? 'ذخیره تغییرات' : 'Save Changes'}
              {hasChanges() && (
                <Badge variant="secondary" className="ml-2">
                  {Object.entries(editedConfig).filter(([subject, edited]) => {
                    const original = contentConfig[subject];
                    return original.availableNotebooks !== edited.count || original.enabled !== edited.enabled;
                  }).length}
                </Badge>
              )}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={resetChanges}
              disabled={!hasChanges()}
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              {language === 'fa' ? 'بازگردانی' : 'Reset'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}