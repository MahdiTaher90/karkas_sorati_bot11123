import { useState } from 'react';
import { useLanguage } from './LanguageProvider';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Calendar, Clock, Sparkles, LayoutGrid, Table2, Download } from 'lucide-react';
import { buildSchedule, Schedule } from '../utils/scheduleGenerator';

export function SchedulePlanner() {
  const { language, t } = useLanguage();
  const [userInput, setUserInput] = useState('');
  const [schedule, setSchedule] = useState<Schedule | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showTableView, setShowTableView] = useState(false);

  const handleGenerate = async () => {
    if (!userInput.trim()) return;
    
    setIsGenerating(true);
    try {
      console.log('🔍 Input text:', userInput);
      // شبیه‌سازی تاخیر برای UX بهتر
      await new Promise(resolve => setTimeout(resolve, 1000));
      const generatedSchedule = buildSchedule(userInput);
      console.log('📅 Generated schedule:', generatedSchedule);
      
      // چک کردن که آیا فعالیت‌ها درست اضافه شدن
      const hasActivities = Object.values(generatedSchedule).some(daySchedule => 
        Object.values(daySchedule).some(activity => activity !== 'Free')
      );
      console.log('✅ Schedule has activities:', hasActivities);
      
      setSchedule(generatedSchedule);
    } catch (error) {
      console.error('❌ Error generating schedule:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleClear = () => {
    setUserInput('');
    setSchedule(null);
  };

  // دانلود جدول به فرمت XLSX
  const downloadAsXLSX = () => {
    if (!schedule) return;
    
    // Import SheetJS dynamically
    import('xlsx').then((XLSX) => {
      const days = Object.keys(schedule);
      const times = days.length > 0 ? Object.keys(schedule[days[0]]) : [];
      
      // ساخت data array برای worksheet
      const data = [];
      
      // Header row
      data.push([language === 'fa' ? 'زمان' : 'Time', ...days]);
      
      // Data rows
      times.forEach(time => {
        const row = [time, ...days.map(day => schedule[day][time] || (language === 'fa' ? 'آزاد' : 'Free'))];
        data.push(row);
      });
      
      // ساخت workbook و worksheet
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.aoa_to_sheet(data);
      
      // تنظیم عرض ستون‌ها
      const colWidths = [
        { wch: 10 }, // Time column
        ...days.map(() => ({ wch: 15 })) // Day columns
      ];
      worksheet['!cols'] = colWidths;
      
      // اضافه کردن worksheet به workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, language === 'fa' ? 'برنامه هفتگی' : 'Weekly Schedule');
      
      // دانلود فایل
      XLSX.writeFile(workbook, `schedule_${new Date().toISOString().split('T')[0]}.xlsx`);
    }).catch((error) => {
      console.error('Error loading XLSX library:', error);
      // Fallback to CSV if XLSX fails
      const days = Object.keys(schedule);
      const times = days.length > 0 ? Object.keys(schedule[days[0]]) : [];
      
      let csv = (language === 'fa' ? 'زمان' : 'Time') + ',' + days.join(',') + '\n';
      
      times.forEach(time => {
        const row = [time, ...days.map(day => schedule[day][time] || (language === 'fa' ? 'آزاد' : 'Free'))];
        csv += row.map(cell => `"${cell}"`).join(',') + '\n';
      });
      
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `schedule_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    });
  };

  // دانلود جدول به فرمت JSON
  const downloadAsJSON = () => {
    if (!schedule) return;
    
    const exportData = {
      generatedAt: new Date().toISOString(),
      schedule: schedule,
      metadata: {
        language: language,
        totalDays: Object.keys(schedule).length,
        timeSlots: Object.keys(schedule[Object.keys(schedule)[0]] || {}).length
      }
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `schedule_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const exampleText = language === 'fa' 
    ? `مثال:
6
هر روز ورزش 7 تا 8
شنبه ریاضی 9 تا 11
یکشنبه فیزیک 10 تا 12
دوشنبه شیمی
مطالعه
22`
    : `Example:
6
Daily exercise 7 to 8
Saturday math 9 to 11
Sunday physics 10 to 12
Monday chemistry
Study
22`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="h-6 w-6 text-primary" />
          <h2 className="text-foreground">{t('schedulePlanner')}</h2>
        </div>
        <p className="text-muted-foreground">
          {t('schedulePlannerDescription')}
        </p>
      </div>

      {/* Input Section */}
      <Card className="bg-card/50 backdrop-blur-sm border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-card-foreground">
            <Calendar className="h-5 w-5 text-accent" />
            {t('enterActivities')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Textarea
              placeholder={exampleText}
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              className="min-h-[200px] resize-none border-primary/20 focus:border-primary bg-input-background/80 backdrop-blur-sm text-foreground"
              dir={language === 'fa' ? 'rtl' : 'ltr'}
            />
            <p className="text-sm text-muted-foreground">
              {t('scheduleInputGuide')}
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={handleGenerate}
              disabled={!userInput.trim() || isGenerating}
              className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25"
            >
              {isGenerating ? (
                <>
                  <Clock className="h-4 w-4 animate-spin text-primary-foreground" />
                  {t('generating')}
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 text-primary-foreground mr-2" />
                  {t('generateSchedule')}
                </>
              )}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => setUserInput(language === 'fa' ? 'هر روز مدرسه 7 تا 14\nشنبه ورزش 16 تا 18' : 'every day school 8 to 16\nMonday exercise 17 to 19')}
              className="border-accent/50 text-accent hover:bg-accent/10"
            >
              {language === 'fa' ? 'مثال' : 'Example'}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={handleClear}
              disabled={!userInput && !schedule}
              className="border-muted-foreground/50 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50"
            >
              {t('clear')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Schedule Display */}
      {schedule && (
        <Card className="bg-card/50 backdrop-blur-sm border-primary/20">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Calendar className="h-5 w-5 text-accent" />
                {t('generatedSchedule')}
              </CardTitle>
              
              <div className="flex items-center gap-2">
                {/* Download Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-2 border-accent/50 text-accent hover:bg-accent/10"
                    >
                      <Download className="h-4 w-4" />
                      <span className="hidden sm:inline">
                        {language === 'fa' ? 'دانلود' : 'Download'}
                      </span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover/95 backdrop-blur-sm border-border">
                    <DropdownMenuItem onClick={downloadAsXLSX} className="text-popover-foreground hover:bg-accent/20">
                      <Download className="h-4 w-4 mr-2 text-accent" />
                      {language === 'fa' ? 'دانلود Excel' : 'Download Excel'}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={downloadAsJSON} className="text-popover-foreground hover:bg-accent/20">
                      <Download className="h-4 w-4 mr-2 text-accent" />
                      {language === 'fa' ? 'دانلود JSON' : 'Download JSON'}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Toggle Button */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowTableView(!showTableView)}
                  className="flex items-center gap-2 border-primary/50 text-primary hover:bg-primary/10"
                >
                  {showTableView ? (
                    <>
                      <LayoutGrid className="h-4 w-4" />
                      <span className="hidden sm:inline">
                        {language === 'fa' ? 'نمای کارت' : 'Card View'}
                      </span>
                    </>
                  ) : (
                    <>
                      <Table2 className="h-4 w-4" />
                      <span className="hidden sm:inline">
                        {language === 'fa' ? 'نمای جدول' : 'Table View'}
                      </span>
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ScheduleTable schedule={schedule} showTableView={showTableView} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

interface ScheduleTableProps {
  schedule: Schedule;
  showTableView: boolean;
}

function ScheduleTable({ schedule, showTableView }: ScheduleTableProps) {
  const { language } = useLanguage();
  
  const days = Object.keys(schedule);
  const times = days.length > 0 ? Object.keys(schedule[days[0]]) : [];

  // تولید رنگ منحصر به فرد برای هر فعالیت - بهبود یافته برای تم جدید
  const getActivityColor = (activity: string): string => {
    if (activity === 'Free') return 'bg-muted/50 text-muted-foreground border border-border/50';
    
    // آرایه رنگ‌های بهبود یافته برای تم Pink Vulture
    const colorPalette = [
      'bg-primary/20 text-primary border border-primary/30',                  // صورتی اصلی
      'bg-accent/20 text-accent-foreground border border-accent/30',           // طلایی
      'bg-secondary/40 text-secondary-foreground border border-secondary',     // بنفش تیره
      'bg-purple-500/20 text-purple-300 border border-purple-400/30',         // بنفش
      'bg-pink-500/20 text-pink-300 border border-pink-400/30',               // صورتی روشن
      'bg-rose-500/20 text-rose-300 border border-rose-400/30',               // گلابی
      'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-400/30',      // ارغوانی
      'bg-violet-500/20 text-violet-300 border border-violet-400/30',         // بنفش روشن
      'bg-amber-500/20 text-amber-300 border border-amber-400/30',            // کهربایی
      'bg-orange-500/20 text-orange-300 border border-orange-400/30',         // نارنجی
      'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30',         // زرد
      'bg-lime-500/20 text-lime-300 border border-lime-400/30',               // سبز روشن
      'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30',      // زمردی
      'bg-teal-500/20 text-teal-300 border border-teal-400/30',               // آبی سبز
      'bg-cyan-500/20 text-cyan-300 border border-cyan-400/30',               // فیروزه‌ای
      'bg-sky-500/20 text-sky-300 border border-sky-400/30',                  // آسمانی
      'bg-blue-500/20 text-blue-300 border border-blue-400/30',               // آبی
      'bg-indigo-500/20 text-indigo-300 border border-indigo-400/30',         // نیلی
      'bg-slate-500/20 text-slate-300 border border-slate-400/30',            // خاکستری
      'bg-red-500/20 text-red-300 border border-red-400/30',                  // قرمز
    ];
    
    // تولید hash منحصر به فرد از نام فعالیت
    let hash = 0;
    const activityLower = activity.toLowerCase().trim();
    for (let i = 0; i < activityLower.length; i++) {
      const char = activityLower.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // تبدیل به 32-bit integer
    }
    
    // انتخاب رنگ بر اساس hash
    const colorIndex = Math.abs(hash) % colorPalette.length;
    return colorPalette[colorIndex];
  };

  // Mobile Card View Component
  const MobileScheduleView = () => (
    <div className={`space-y-4 ${showTableView ? 'hidden' : 'block md:hidden'}`}>
      {days.map(day => (
        <Card key={day} className="overflow-hidden bg-card/60 backdrop-blur-sm border-border/50">
          <CardHeader className="pb-3 bg-primary/5 border-b border-border/50">
            <h3 className="text-lg font-medium text-center text-card-foreground">{day}</h3>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-3">
              {times.map(time => {
                const activity = schedule[day]?.[time] || 'Free';
                if (activity === 'Free') return null;
                
                return (
                  <div key={time} className="flex items-center gap-3">
                    <div className="text-sm text-muted-foreground min-w-[50px] text-center font-medium">
                      {time}
                    </div>
                    <div 
                      className={`flex-1 p-3 rounded-lg text-sm font-medium shadow-sm backdrop-blur-sm ${getActivityColor(activity)}`}
                    >
                      {activity}
                    </div>
                  </div>
                );
              })}
              {/* اگر هیچ فعالیتی نداشت */}
              {times.every(time => schedule[day]?.[time] === 'Free') && (
                <div className="text-center text-muted-foreground py-8">
                  {language === 'fa' ? 'بدون فعالیت' : 'No activities'}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  // Desktop Table View Component  
  const DesktopScheduleView = () => (
    <div className={`overflow-auto rounded-lg ${showTableView ? 'block' : 'hidden md:block'}`}>
      <table className="w-full border-collapse border border-border/50 bg-card/30 backdrop-blur-sm">
        <thead>
          <tr>
            <th className="border border-border/50 p-3 bg-primary/10 backdrop-blur-sm sticky left-0 z-10 text-foreground font-medium">
              {language === 'fa' ? 'زمان' : 'Time'}
            </th>
            {days.map(day => (
              <th key={day} className="border border-border/50 p-3 bg-primary/10 backdrop-blur-sm min-w-[120px] text-foreground font-medium">
                {day}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {times.map(time => (
            <tr key={time}>
              <td className="border border-border/50 p-3 bg-primary/5 font-medium text-center sticky left-0 z-10 text-foreground backdrop-blur-sm">
                {time}
              </td>
              {days.map(day => {
                const activity = schedule[day]?.[time] || 'Free';
                return (
                  <td key={`${day}-${time}`} className="border border-border/50 p-2">
                    <div 
                      className={`p-3 rounded-lg text-center text-sm min-h-[50px] flex items-center justify-center font-medium shadow-sm backdrop-blur-sm ${getActivityColor(activity)}`}
                    >
                      {activity !== 'Free' ? activity : ''}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="w-full">
      <MobileScheduleView />
      <DesktopScheduleView />
    </div>
  );
}