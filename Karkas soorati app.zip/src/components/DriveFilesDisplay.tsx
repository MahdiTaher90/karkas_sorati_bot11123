import { useState } from 'react';
import { useLanguage } from './LanguageProvider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { FolderOpen, FileText, ExternalLink, Search, Filter } from 'lucide-react';
import { contentConfig } from '../data/contentConfig';

interface DriveFile {
  name: string;
  url: string;
  subject: string;
  week?: number;
  size?: string;
  type: 'pdf' | 'doc' | 'other';
}

export function DriveFilesDisplay() {
  const { language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  
  // فایل‌های نمونه (در اپلیکیشن واقعی باید از API گرفته شود)
  const sampleFiles: DriveFile[] = [
    {
      name: 'ریاضی - هفته اول مهر.pdf',
      url: 'https://drive.google.com/file/d/sample1/view',
      subject: 'ریاضی',
      week: 1,
      size: '2.3 MB',
      type: 'pdf'
    },
    {
      name: 'فیزیک - هفته دوم مهر.pdf',
      url: 'https://drive.google.com/file/d/sample2/view',
      subject: 'فیزیک',
      week: 2,
      size: '1.8 MB',
      type: 'pdf'
    },
    // می‌توان فایل‌های بیشتری اضافه کرد
  ];

  const filteredFiles = sampleFiles.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || file.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return '📄';
      case 'doc':
        return '📝';
      default:
        return '📁';
    }
  };

  const subjects = Object.keys(contentConfig).filter(subject => contentConfig[subject].enabled);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <FolderOpen className="h-4 w-4" />
          {language === 'fa' ? 'مشاهده فایل‌ها' : 'View Files'}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5" />
            {language === 'fa' ? 'فایل‌های گوگل درایو' : 'Google Drive Files'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* جست‌وجو و فیلتر */}
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={language === 'fa' ? 'جست‌وجو در فایل‌ها...' : 'Search files...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              className="px-3 py-2 border rounded-md"
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
            >
              <option value="all">
                {language === 'fa' ? 'همه دروس' : 'All Subjects'}
              </option>
              {subjects.map(subject => (
                <option key={subject} value={subject}>{subject}</option>
              ))}
            </select>
          </div>

          {/* آمار سریع */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="text-2xl font-medium text-blue-600">{filteredFiles.length}</div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'فایل یافت شد' : 'Files Found'}
                </div>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="text-2xl font-medium text-green-600">
                  {new Set(filteredFiles.map(f => f.subject)).size}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'درس' : 'Subjects'}
                </div>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="text-2xl font-medium text-purple-600">
                  {filteredFiles.filter(f => f.type === 'pdf').length}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'فایل PDF' : 'PDF Files'}
                </div>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-4">
                <div className="text-2xl font-medium text-orange-600">
                  {filteredFiles.reduce((total, file) => {
                    if (file.size) {
                      const size = parseFloat(file.size.replace(' MB', ''));
                      return total + size;
                    }
                    return total;
                  }, 0).toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'مگابایت' : 'MB Total'}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* لیست فایل‌ها */}
          <Tabs value="list" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="list">
                {language === 'fa' ? 'نمای لیست' : 'List View'}
              </TabsTrigger>
              <TabsTrigger value="grid">
                {language === 'fa' ? 'نمای شبکه' : 'Grid View'}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="list" className="space-y-3">
              {filteredFiles.length === 0 ? (
                <Card>
                  <CardContent className="text-center py-8">
                    <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">
                      {language === 'fa' ? 'هیچ فایلی یافت نشد' : 'No files found'}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                filteredFiles.map((file, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{getFileIcon(file.type)}</span>
                          <div>
                            <div className="font-medium">{file.name}</div>
                            <div className="text-sm text-muted-foreground flex items-center gap-2">
                              <Badge variant="outline">{file.subject}</Badge>
                              {file.week && (
                                <span>
                                  {language === 'fa' ? `هفته ${file.week}` : `Week ${file.week}`}
                                </span>
                              )}
                              {file.size && <span>{file.size}</span>}
                            </div>
                          </div>
                        </div>
                        
                        <Button variant="outline" size="sm" asChild>
                          <a href={file.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
            
            <TabsContent value="grid">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredFiles.map((file, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-4xl mb-2">{getFileIcon(file.type)}</div>
                        <div className="font-medium mb-2 line-clamp-2">{file.name}</div>
                        <div className="space-y-1 mb-3">
                          <Badge variant="outline">{file.subject}</Badge>
                          {file.week && (
                            <div className="text-sm text-muted-foreground">
                              {language === 'fa' ? `هفته ${file.week}` : `Week ${file.week}`}
                            </div>
                          )}
                          {file.size && (
                            <div className="text-sm text-muted-foreground">{file.size}</div>
                          )}
                        </div>
                        <Button variant="outline" size="sm" asChild className="w-full">
                          <a href={file.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-2" />
                            {language === 'fa' ? 'مشاهده' : 'View'}
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}