import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, ExternalLink, FileSpreadsheet, AlertTriangle } from 'lucide-react';
import { useLanguage } from './LanguageProvider';

export function CSVGuide() {
  const { language } = useLanguage();

  const csvUrl = 'https://docs.google.com/spreadsheets/d/15h2sEHTinULt6B4mdBMLGZpcGkNs0xAiFItKeHra3fs/edit?usp=sharing';

  const openCSV = () => {
    window.open(csvUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-accent" />
          {language === 'fa' ? 'راهنمای Google Sheets' : 'Google Sheets Guide'}
        </CardTitle>
        <CardDescription>
          {language === 'fa' 
            ? 'نحوه تنظیم و استفاده از فایل CSV برای مدیریت جزوه‌ها'
            : 'How to set up and use CSV file for managing notebooks'
          }
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* CSV Structure */}
        <div className="space-y-3">
          <h4 className="font-medium flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            {language === 'fa' ? 'ساختار فایل CSV' : 'CSV File Structure'}
          </h4>
          <div className="bg-muted/50 p-3 rounded-md font-mono text-sm">
            <div className="text-accent-foreground font-semibold mb-2">
              file_id,file_name,subject
            </div>
            <div className="space-y-1 text-muted-foreground">
              <div>1BCD_example,Physics Week 1,فیزیک</div>
              <div>1BCD_math01,Math Chapter 1,ریاضی</div>
              <div>1BCD_chem01,Chemistry Notes,شیمی</div>
            </div>
          </div>
        </div>

        {/* Column Descriptions */}
        <div className="space-y-3">
          <h4 className="font-medium">
            {language === 'fa' ? 'توضیح ستون‌ها' : 'Column Descriptions'}
          </h4>
          <div className="space-y-2">
            <div className="flex items-start gap-3 p-2 bg-primary/5 rounded">
              <Badge variant="outline" className="mt-0.5">file_id</Badge>
              <div className="text-sm">
                <div className="font-medium">
                  {language === 'fa' ? 'شناسه فایل گوگل درایو' : 'Google Drive File ID'}
                </div>
                <div className="text-muted-foreground">
                  {language === 'fa' 
                    ? 'بخشی از لینک گوگل درایو که بین /d/ و /view قرار دارد'
                    : 'Part of Google Drive link between /d/ and /view'
                  }
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-2 bg-accent/5 rounded">
              <Badge variant="outline" className="mt-0.5">file_name</Badge>
              <div className="text-sm">
                <div className="font-medium">
                  {language === 'fa' ? 'نام فایل' : 'File Name'}
                </div>
                <div className="text-muted-foreground">
                  {language === 'fa' 
                    ? 'نام نمایشی که کاربران خواهند دید'
                    : 'Display name that users will see'
                  }
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-2 bg-chart-3/5 rounded">
              <Badge variant="outline" className="mt-0.5">subject</Badge>
              <div className="text-sm">
                <div className="font-medium">
                  {language === 'fa' ? 'موضوع درس' : 'Subject'}
                </div>
                <div className="text-muted-foreground">
                  {language === 'fa' 
                    ? 'نام موضوع باید دقیقاً مطابق لیست زیر باشد'
                    : 'Subject name must exactly match the list below'
                  }
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Valid Subjects */}
        <div className="space-y-3">
          <h4 className="font-medium">
            {language === 'fa' ? 'موضوعات معتبر' : 'Valid Subjects'}
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {[
              'ریاضی', 'فیزیک', 'شیمی', 'زیست‌شناسی', 'کامپیوتر', 'جبر',
              'المپیاد نجوم', 'المپیاد فیزیک', 'المپیاد ریاضی', 'المپیاد کامپیوتر'
            ].map(subject => (
              <Badge key={subject} variant="secondary" className="justify-center">
                {subject}
              </Badge>
            ))}
          </div>
        </div>

        {/* Access Link */}
        <div className="space-y-3">
          <h4 className="font-medium flex items-center gap-2">
            <ExternalLink className="h-4 w-4 text-primary" />
            {language === 'fa' ? 'دسترسی به فایل' : 'Access File'}
          </h4>
          <div className="p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors" onClick={openCSV}>
            <div className="text-sm font-medium mb-1">Google Sheets CSV</div>
            <div className="text-xs text-muted-foreground break-all">{csvUrl}</div>
          </div>
        </div>

        {/* Notes */}
        <div className="space-y-3">
          <h4 className="font-medium flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            {language === 'fa' ? 'نکات مهم' : 'Important Notes'}
          </h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <span className="w-1 h-1 bg-current rounded-full mt-2 flex-shrink-0" />
              {language === 'fa' 
                ? 'فایل باید به صورت عمومی قابل دسترسی باشد'
                : 'File must be publicly accessible'
              }
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1 h-1 bg-current rounded-full mt-2 flex-shrink-0" />
              {language === 'fa' 
                ? 'نام موضوعات باید دقیقاً مطابق لیست بالا باشد'
                : 'Subject names must exactly match the list above'
              }
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1 h-1 bg-current rounded-full mt-2 flex-shrink-0" />
              {language === 'fa' 
                ? 'شناسه فایل باید از لینک گوگل درایو استخراج شود'
                : 'File ID must be extracted from Google Drive link'
              }
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}