import { useState } from 'react';
import { useLanguage } from './LanguageProvider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { FolderOpen, Upload, RefreshCw, CheckCircle, AlertCircle, Download } from 'lucide-react';
import { contentConfig, updateAvailableNotebooks } from '../data/contentConfig';

interface SubjectCount {
  subject: string;
  count: number;
  status: 'new' | 'updated' | 'unchanged';
}

export function DriveContentScanner() {
  const { language } = useLanguage();
  const [inputText, setInputText] = useState('');
  const [parsedResults, setParsedResults] = useState<SubjectCount[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  // نقشه‌برداری نام پوشه‌ها به نام‌های دروس
  const folderMapping: Record<string, string> = {
    'math': 'ریاضی',
    'mathematics': 'ریاضی',
    'riazi': 'ریاضی',
    'ریاضی': 'ریاضی',
    
    'physics': 'فیزیک',
    'fizik': 'فیزیک',
    'فیزیک': 'فیزیک',
    
    'chemistry': 'شیمی',
    'shimi': 'شیمی',
    'شیمی': 'شیمی',
    
    'biology': 'زیست‌شناسی',
    'zist': 'زیست‌شناسی',
    'زیست': 'زیست‌شناسی',
    'زیست‌شناسی': 'زیست‌شناسی',
    
    'persian': 'ادبیات فارسی',
    'literature': 'ادبیات فارسی',
    'adabiyat': 'ادبیات فارسی',
    'ادبیات': 'ادبیات فارسی',
    'ادبیات فارسی': 'ادبیات فارسی',
    
    'english': 'انگلیسی',
    'انگلیسی': 'انگلیسی',
    
    'computer': 'کامپیوتر',
    'cs': 'کامپیوتر',
    'کامپیوتر': 'کامپیوتر',
    
    'algebra': 'جبر',
    'jabr': 'جبر',
    'جبر': 'جبر',
    
    'astronomy': 'المپیاد نجوم',
    'olympiad-astronomy': 'المپیاد نجوم',
    'نجوم': 'المپیاد نجوم',
    'المپیاد نجوم': 'المپیاد نجوم',
    
    'olympiad-physics': 'المپیاد فیزیک',
    'المپیاد فیزیک': 'المپیاد فیزیک',
    
    'olympiad-math': 'المپیاد ریاضی',
    'المپیاد ریاضی': 'المپیاد ریاضی',
    
    'olympiad-computer': 'المپیاد کامپیوتر',
    'المپیاد کامپیوتر': 'المپیاد کامپیوتر'
  };

  const parseInputText = () => {
    setIsProcessing(true);
    
    try {
      const lines = inputText.split('\n').filter(line => line.trim());
      const results: SubjectCount[] = [];
      
      // روش 1: پارس کردن متن ساختاریافته (مثل: "ریاضی: 5 فایل")
      const structuredPattern = /^(.+?):\s*(\d+)/;
      
      // روش 2: پارس کردن لیست فایل‌ها (هر خط یک فایل)
      const folderCounts: Record<string, number> = {};
      
      for (const line of lines) {
        const trimmedLine = line.trim();
        
        // بررسی الگوی ساختاریافته
        const structuredMatch = trimmedLine.match(structuredPattern);
        if (structuredMatch) {
          const [, subject, count] = structuredMatch;
          const normalizedSubject = findSubjectName(subject.trim());
          if (normalizedSubject) {
            const currentCount = contentConfig[normalizedSubject]?.availableNotebooks || 0;
            const newCount = parseInt(count);
            results.push({
              subject: normalizedSubject,
              count: newCount,
              status: newCount !== currentCount ? 'updated' : 'unchanged'
            });
          }
          continue;
        }
        
        // بررسی نام فایل برای تشخیص پوشه درس
        const fileName = trimmedLine.toLowerCase();
        for (const [folder, subject] of Object.entries(folderMapping)) {
          if (fileName.includes(folder)) {
            folderCounts[subject] = (folderCounts[subject] || 0) + 1;
            break;
          }
        }
      }
      
      // اضافه کردن نتایج از شمارش فایل‌ها
      for (const [subject, count] of Object.entries(folderCounts)) {
        if (!results.find(r => r.subject === subject)) {
          const currentCount = contentConfig[subject]?.availableNotebooks || 0;
          results.push({
            subject,
            count,
            status: count !== currentCount ? 'updated' : 'unchanged'
          });
        }
      }
      
      setParsedResults(results);
      setShowPreview(true);
      
    } catch (error) {
      console.error('Error parsing input:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const findSubjectName = (input: string): string | null => {
    const normalized = input.toLowerCase().trim();
    
    // جستجوی مستقیم
    if (folderMapping[normalized]) {
      return folderMapping[normalized];
    }
    
    // جستجوی جزئی
    for (const [key, value] of Object.entries(folderMapping)) {
      if (normalized.includes(key) || key.includes(normalized)) {
        return value;
      }
    }
    
    return null;
  };

  const applyChanges = () => {
    let changesCount = 0;
    
    for (const result of parsedResults) {
      if (result.status !== 'unchanged') {
        updateAvailableNotebooks(result.subject, result.count);
        
        // فعال کردن درس اگر جزوه جدید اضافه شده
        if (result.count > 0 && contentConfig[result.subject]) {
          contentConfig[result.subject].enabled = true;
        }
        
        changesCount++;
      }
    }
    
    if (changesCount > 0) {
      console.log(`✅ ${changesCount} درس به‌روزرسانی شد`);
      window.location.reload();
    }
  };

  const generateTemplate = () => {
    const template = Object.keys(contentConfig).map(subject => {
      const current = contentConfig[subject]?.availableNotebooks || 0;
      return `${subject}: ${current}`;
    }).join('\n');
    
    setInputText(template);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <FolderOpen className="h-4 w-4" />
          {language === 'fa' ? 'اسکن درایو' : 'Scan Drive'}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5" />
            {language === 'fa' ? 'اسکنر محتوای گوگل درایو' : 'Google Drive Content Scanner'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* راهنما */}
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {language === 'fa' ? (
                <>
                  <strong>نحوه استفاده:</strong><br />
                  1. به گوگل درایو بروید و محتویات هر پوشه درس را کپی کنید<br />
                  2. متن را در کادر زیر paste کنید<br />
                  3. روی "تحلیل" کلیک کنید تا سیستم تعداد جزوه‌ها را بشمارد
                </>
              ) : (
                <>
                  <strong>How to use:</strong><br />
                  1. Go to Google Drive and copy the contents of each subject folder<br />
                  2. Paste the text in the box below<br />
                  3. Click "Analyze" to count the notebooks
                </>
              )}
            </AlertDescription>
          </Alert>

          {/* ورودی */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  {language === 'fa' ? 'وارد کردن اطلاعات' : 'Input Data'}
                </span>
                <Button variant="outline" size="sm" onClick={generateTemplate}>
                  <Download className="h-4 w-4 mr-2" />
                  {language === 'fa' ? 'قالب' : 'Template'}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder={language === 'fa' ? 
                  "مثال:\nریاضی: 5\nفیزیک: 3\nیا لیست فایل‌ها:\nmath-week1.pdf\nmath-week2.pdf\nphysics-week1.pdf" :
                  "Example:\nMathematics: 5\nPhysics: 3\nOr file list:\nmath-week1.pdf\nmath-week2.pdf\nphysics-week1.pdf"
                }
                rows={8}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
              />
              
              <Button 
                onClick={parseInputText} 
                disabled={!inputText.trim() || isProcessing}
                className="w-full"
              >
                {isProcessing ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Upload className="h-4 w-4 mr-2" />
                )}
                {language === 'fa' ? 'تحلیل محتوا' : 'Analyze Content'}
              </Button>
            </CardContent>
          </Card>

          {/* پیش‌نمایش نتایج */}
          {showPreview && parsedResults.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  {language === 'fa' ? 'پیش‌نمایش تغییرات' : 'Preview Changes'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {parsedResults.map((result, index) => (
                    <div 
                      key={index}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <div className="font-medium">{result.subject}</div>
                        <div className="text-sm text-muted-foreground">
                          {language === 'fa' ? 
                            `فعلی: ${contentConfig[result.subject]?.availableNotebooks || 0} → جدید: ${result.count}` :
                            `Current: ${contentConfig[result.subject]?.availableNotebooks || 0} → New: ${result.count}`
                          }
                        </div>
                      </div>
                      <Badge 
                        variant={
                          result.status === 'updated' ? 'default' : 
                          result.status === 'new' ? 'secondary' : 'outline'
                        }
                      >
                        {language === 'fa' ? (
                          result.status === 'updated' ? 'به‌روزرسانی' :
                          result.status === 'new' ? 'جدید' : 'بدون تغییر'
                        ) : (
                          result.status === 'updated' ? 'Updated' :
                          result.status === 'new' ? 'New' : 'Unchanged'
                        )}
                      </Badge>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 flex gap-3">
                  <Button onClick={applyChanges} className="flex-1">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    {language === 'fa' ? 'اعمال تغییرات' : 'Apply Changes'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowPreview(false);
                      setParsedResults([]);
                    }}
                  >
                    {language === 'fa' ? 'لغو' : 'Cancel'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* نتایج خالی */}
          {showPreview && parsedResults.length === 0 && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {language === 'fa' ? 
                  'هیچ درس معتبری شناسایی نشد. لطفاً فرمت ورودی را بررسی کنید.' :
                  'No valid subjects detected. Please check the input format.'
                }
              </AlertDescription>
            </Alert>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}