import { AlertCircle, CheckCircle, Database, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { useLanguage } from './LanguageProvider';

interface CSVStatusDisplayProps {
  isLoading: boolean;
  error: string | null;
  dataCount: number;
  subjectCount: number;
  lastUpdated: Date | null;
  onRetry: () => void;
}

export function CSVStatusDisplay({ 
  isLoading, 
  error, 
  dataCount, 
  subjectCount, 
  lastUpdated, 
  onRetry 
}: CSVStatusDisplayProps) {
  const { language } = useLanguage();

  const getStatusIcon = () => {
    if (isLoading) return <RefreshCw className="h-5 w-5 animate-spin text-primary" />;
    if (error) return <AlertCircle className="h-5 w-5 text-destructive" />;
    if (dataCount > 0) return <CheckCircle className="h-5 w-5 text-green-600" />;
    return <Database className="h-5 w-5 text-muted-foreground" />;
  };

  const getStatusText = () => {
    if (isLoading) return language === 'fa' ? 'در حال بارگذاری...' : 'Loading...';
    if (error) return language === 'fa' ? 'خطا در بارگذاری' : 'Loading Error';
    if (dataCount > 0) return language === 'fa' ? 'بارگذاری موفق' : 'Successfully Loaded';
    return language === 'fa' ? 'آماده بارگذاری' : 'Ready to Load';
  };

  const getStatusColor = () => {
    if (isLoading) return 'border-primary/50 bg-primary/5';
    if (error) return 'border-destructive/50 bg-destructive/5';
    if (dataCount > 0) return 'border-green-500/50 bg-green-50 dark:bg-green-900/10';
    return 'border-muted-foreground/50 bg-muted/20';
  };

  return (
    <Card className={`${getStatusColor()} transition-colors`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            <CardTitle className="text-base">
              {language === 'fa' ? 'وضعیت داده‌های CSV' : 'CSV Data Status'}
            </CardTitle>
          </div>
          <Badge variant={error ? 'destructive' : dataCount > 0 ? 'default' : 'secondary'}>
            {getStatusText()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <div className="space-y-2">
            <p className="text-sm text-destructive font-medium">
              {language === 'fa' ? 'جزئیات خطا:' : 'Error Details:'}
            </p>
            <p className="text-xs text-muted-foreground bg-destructive/10 p-2 rounded border">
              {error}
            </p>
            <Button onClick={onRetry} variant="outline" size="sm" className="w-full">
              <RefreshCw className="h-4 w-4 mr-2" />
              {language === 'fa' ? 'تلاش مجدد' : 'Try Again'}
            </Button>
          </div>
        )}

        {dataCount > 0 && (
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-lg font-bold text-primary">{subjectCount}</div>
              <div className="text-xs text-muted-foreground">
                {language === 'fa' ? 'موضوع' : 'Subjects'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-accent-foreground">{dataCount}</div>
              <div className="text-xs text-muted-foreground">
                {language === 'fa' ? 'فایل' : 'Files'}
              </div>
            </div>
          </div>
        )}

        {lastUpdated && (
          <CardDescription className="text-center text-xs">
            {language === 'fa' 
              ? `آخرین به‌روزرسانی: ${lastUpdated.toLocaleString('fa-IR')}`
              : `Last updated: ${lastUpdated.toLocaleString()}`
            }
          </CardDescription>
        )}

        {!error && !isLoading && dataCount === 0 && (
          <div className="text-center py-4">
            <Database className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {language === 'fa' 
                ? 'برای شروع، دکمه "به‌روزرسانی داده‌ها" را کلیک کنید'
                : 'Click "Refresh Data" to get started'
              }
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}