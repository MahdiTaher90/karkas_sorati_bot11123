import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { FileText, AlertCircle } from 'lucide-react';
import { useLanguage } from './LanguageProvider';

interface CSVData {
  [subject: string]: { file_id: string; file_name: string; subject: string; }[];
}

interface CSVSubjectSelectorProps {
  csvData: CSVData;
  onSelectSubject: (subject: string, data: CSVData) => void;
}

export function CSVSubjectSelector({ csvData, onSelectSubject }: CSVSubjectSelectorProps) {
  const [subjects, setSubjects] = useState<string[]>([]);
  const { language } = useLanguage();

  useEffect(() => {
    setSubjects(Object.keys(csvData));
  }, [csvData]);

  if (subjects.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">
            {language === 'fa' ? 'هیچ داده‌ای موجود نیست' : 'No data available'}
          </h3>
          <p className="text-muted-foreground text-center">
            {language === 'fa' 
              ? 'ابتدا داده‌ها را از CSV بارگذاری کنید'
              : 'Please load data from CSV first'
            }
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2>
          {language === 'fa' ? 'انتخاب موضوع از داده‌های CSV' : 'Select Subject from CSV Data'}
        </h2>
        <p className="text-muted-foreground">
          {language === 'fa' 
            ? 'موضوع مورد نظر خود را برای مشاهده جزوه‌ها انتخاب کنید'
            : 'Choose a subject to view available notebooks'
          }
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {subjects.map((subject) => {
          const fileCount = csvData[subject].length;
          
          return (
            <Card 
              key={subject}
              className="cursor-pointer transition-all hover:shadow-lg hover:scale-105 border-2 hover:border-primary/20"
              onClick={() => onSelectSubject(subject, csvData)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{subject}</CardTitle>
                  <FileText className="h-5 w-5 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Badge variant="secondary" className="w-fit">
                    {fileCount} {language === 'fa' ? 'فایل' : 'files'}
                  </Badge>
                  
                  <CardDescription>
                    {language === 'fa' 
                      ? `${fileCount} جزوه موجود در این موضوع`
                      : `${fileCount} notebooks available in this subject`
                    }
                  </CardDescription>
                  
                  <Button size="sm" className="w-full">
                    {language === 'fa' ? 'مشاهده جزوه‌ها' : 'View Notebooks'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="text-center p-4 bg-muted/50 rounded-lg">
        <p className="text-sm text-muted-foreground">
          {language === 'fa' 
            ? `مجموعاً ${subjects.length} موضوع و ${Object.values(csvData).reduce((sum, files) => sum + files.length, 0)} فایل موجود است`
            : `Total: ${subjects.length} subjects and ${Object.values(csvData).reduce((sum, files) => sum + files.length, 0)} files available`
          }
        </p>
      </div>
    </div>
  );
}