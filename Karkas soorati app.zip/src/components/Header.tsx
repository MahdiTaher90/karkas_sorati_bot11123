import image_b21aded68d1e7f543a48b5cf7a05c4fbd0231afa from 'figma:asset/b21aded68d1e7f543a48b5cf7a05c4fbd0231afa.png';
import image_9a01627925d24c8a1255782bc9e4c0fa239568f3 from 'figma:asset/9a01627925d24c8a1255782bc9e4c0fa239568f3.png';
import image_b70f3bdab3f817f4ebd714ead68a2bf2f492fb4d from 'figma:asset/b70f3bdab3f817f4ebd714ead68a2bf2f492fb4d.png';
import image_6a8a3778177b0b3fbd4a87921ff6c5d4517d8140 from 'figma:asset/6a8a3778177b0b3fbd4a87921ff6c5d4517d8140.png';
import { Moon, Sun, ArrowRight, ArrowLeft, Languages, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { useTheme } from './ThemeProvider';
import { useLanguage } from './LanguageProvider';
import logoImage from 'figma:asset/11632732f6fa7b6b81b321f6da5600df273af837.png';

interface HeaderProps {
  showBackButton?: boolean;
  onBack?: () => void;
  subjectName?: string;
  onRefresh?: () => void;
}

export function Header({ showBackButton = false, onBack, subjectName, onRefresh }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const { language, toggleLanguage, t } = useLanguage();

  const BackIcon = language === 'fa' ? ArrowRight : ArrowLeft;

  return (
    <header className="border-b border-accent/30 bg-card/90 backdrop-blur-md shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {showBackButton && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="h-8 w-8"
            >
              <BackIcon className="h-4 w-4" />
            </Button>
          )}
          <img 
            src={image_b21aded68d1e7f543a48b5cf7a05c4fbd0231afa} 
            alt="Karkase Class Logo" 
            className="h-8 w-8 object-contain"
          />
          <div>
            <h1 className="not-italic font-normal">{t('appName')}</h1>
            {subjectName && (
              <p className="text-sm text-muted-foreground">{subjectName}</p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={onRefresh}
            className="h-9 w-9 border-accent/50 hover:bg-accent/20 hover:text-accent-foreground"
            title={t('refresh')}
          >
            <RefreshCw className="h-4 w-4" />
            <span className="sr-only">{t('refresh')}</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={toggleLanguage}
            className="h-9 px-3 gap-2 border-accent/50 hover:bg-accent/20 hover:text-accent-foreground"
          >
            <Languages className="h-4 w-4" />
            <span className="text-sm">{t('languageToggle')}</span>
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="h-9 w-9 border-accent/50 hover:bg-accent/20 hover:text-accent-foreground"
          >
            {theme === 'light' ? (
              <Moon className="h-4 w-4" />
            ) : (
              <Sun className="h-4 w-4" />
            )}
            <span className="sr-only">{t('themeToggle')}</span>
          </Button>
        </div>
      </div>
    </header>
  );
}