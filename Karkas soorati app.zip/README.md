
  # Karkas soorati app

  This is a code bundle for Karkas soorati app. The original project is available at https://www.figma.com/design/zYPI8o4TeN3IizCzigv3IX/Karkas-soorati-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  