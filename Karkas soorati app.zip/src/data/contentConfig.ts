// تنظیمات محتوای اپلیکیشن
export interface ContentStatus {
  // وضعیت کلی درس
  enabled: boolean;
  // تعداد جزوه‌های موجود (باقی به صورت "coming soon" نمایش داده می‌شوند)
  availableNotebooks: number;
  // آخرین هفته‌ای که آپدیت شده
  lastUpdatedWeek?: number;
  // پیغام سفارشی برای کاربران
  customMessage?: {
    fa: string;
    en: string;
  };
}

// تنظیمات هر درس - همه درس‌ها فعال و دارای 35 جزوه
export const contentConfig: Record<string, ContentStatus> = {
  // دروس اصلی
  'ریاضی': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'فیزیک': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'شیمی': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'زیست‌شناسی': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  

  
  // دروس تخصصی
  'کامپیوتر': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'جبر': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  // المپیادها
  'المپیاد نجوم': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'المپیاد فیزیک': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'المپیاد ریاضی': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  },
  
  'المپیاد کامپیوتر': {
    enabled: true,
    availableNotebooks: 35,
    lastUpdatedWeek: 35
  }
};

// تابع کمکی برای بررسی دسترسی به جزوه
export function isNotebookAvailable(subjectName: string, notebookIndex: number): boolean {
  const config = contentConfig[subjectName];
  if (!config || !config.enabled) return false;
  return notebookIndex < config.availableNotebooks;
}

// تابع کمکی برای گرفتن وضعیت درس
export function getSubjectStatus(subjectName: string): ContentStatus | null {
  return contentConfig[subjectName] || null;
}

// تابع کمکی برای آپدیت تعداد جزوه‌های موجود
export function updateAvailableNotebooks(subjectName: string, count: number): void {
  if (contentConfig[subjectName]) {
    contentConfig[subjectName].availableNotebooks = count;
    contentConfig[subjectName].lastUpdatedWeek = count;
  }
}

// آمار کلی اپلیکیشن
export function getOverallStats() {
  const subjects = Object.values(contentConfig);
  const enabledSubjects = subjects.filter(s => s.enabled).length;
  const totalNotebooks = subjects.reduce((sum, s) => sum + s.availableNotebooks, 0);
  const disabledSubjects = subjects.filter(s => !s.enabled).length;
  
  return {
    enabledSubjects,
    totalNotebooks,
    disabledSubjects,
    totalSubjects: subjects.length,
    completion: Math.round((totalNotebooks / (35 * subjects.length)) * 100)
  };
}