import { useState } from 'react';
import { useLanguage } from './LanguageProvider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Settings, Plus, Save, BarChart3, Eye, EyeOff, Link } from 'lucide-react';
import { contentConfig, getOverallStats } from '../data/contentConfig';

export function AdminPanel() {
  const { language } = useLanguage();
  const [quickUpdateSubject, setQuickUpdateSubject] = useState('');
  const [quickUpdateCount, setQuickUpdateCount] = useState('');
  const [quickUpdateLink, setQuickUpdateLink] = useState('');

  const stats = getOverallStats();

  const handleQuickUpdate = () => {
    if (quickUpdateSubject && quickUpdateCount) {
      const count = parseInt(quickUpdateCount);
      if (contentConfig[quickUpdateSubject] && count >= 0 && count <= 35) {
        contentConfig[quickUpdateSubject].availableNotebooks = count;
        contentConfig[quickUpdateSubject].lastUpdatedWeek = count;
        
        console.log(`✅ ${quickUpdateSubject}: ${count} جزوه فعال شد`);
        
        setQuickUpdateSubject('');
        setQuickUpdateCount('');
        setQuickUpdateLink('');
        
        window.location.reload();
      }
    }
  };

  const enabledSubjects = Object.entries(contentConfig).filter(([_, config]) => config.enabled);
  const disabledSubjects = Object.entries(contentConfig).filter(([_, config]) => !config.enabled);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="fixed top-4 left-4 z-40 opacity-50 hover:opacity-100"
        >
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            {language === 'fa' ? 'پنل مدیریت کرکس صورتی' : 'Pink Vulture Admin Panel'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* آمار کلی */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                {language === 'fa' ? 'آمار کلی' : 'Overall Statistics'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-medium text-green-600">{stats.enabledSubjects}</div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'fa' ? 'درس فعال' : 'Active Subjects'}
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-medium text-blue-600">{stats.totalNotebooks}</div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'fa' ? 'جزوه موجود' : 'Available Notebooks'}
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-medium text-purple-600">{stats.completion}%</div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'fa' ? 'پیشرفت' : 'Progress'}
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-medium text-orange-600">{stats.disabledSubjects}</div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'fa' ? 'در انتظار' : 'Disabled'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* آپدیت سریع */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                {language === 'fa' ? 'افزودن جزوه جدید' : 'Add New Notebook'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium">
                    {language === 'fa' ? 'انتخاب درس' : 'Select Subject'}
                  </label>
                  <select
                    className="w-full mt-1 p-2 border rounded-md"
                    value={quickUpdateSubject}
                    onChange={(e) => setQuickUpdateSubject(e.target.value)}
                  >
                    <option value="">
                      {language === 'fa' ? 'انتخاب کنید...' : 'Select...'}
                    </option>
                    {Object.keys(contentConfig).map(subject => (
                      <option key={subject} value={subject}>{subject}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-sm font-medium">
                    {language === 'fa' ? 'تعداد جزوه' : 'Notebook Count'}
                  </label>
                  <Input
                    type="number"
                    min="0"
                    max="35"
                    placeholder="0-35"
                    value={quickUpdateCount}
                    onChange={(e) => setQuickUpdateCount(e.target.value)}
                  />
                </div>

                <div className="flex items-end">
                  <Button onClick={handleQuickUpdate} className="w-full">
                    <Save className="h-4 w-4 mr-2" />
                    {language === 'fa' ? 'به‌روزرسانی' : 'Update'}
                  </Button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">
                  {language === 'fa' ? 'لینک گوگل درایو (اختیاری)' : 'Google Drive Link (Optional)'}
                </label>
                <div className="flex gap-2 mt-1">
                  <Input
                    placeholder="https://drive.google.com/file/d/..."
                    value={quickUpdateLink}
                    onChange={(e) => setQuickUpdateLink(e.target.value)}
                  />
                  <Button variant="outline" size="sm">
                    <Link className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* وضعیت دروس */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* دروس فعال */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5 text-green-600" />
                  {language === 'fa' ? 'دروس فعال' : 'Active Subjects'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {enabledSubjects.map(([subject, config]) => (
                  <div 
                    key={subject}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div>
                      <div className="font-medium">{subject}</div>
                      {config.customMessage && (
                        <div className="text-xs text-muted-foreground">
                          {language === 'fa' ? config.customMessage.fa : config.customMessage.en}
                        </div>
                      )}
                    </div>
                    <Badge variant="default">
                      {config.availableNotebooks}/35
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* دروس غیرفعال */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <EyeOff className="h-5 w-5 text-orange-600" />
                  {language === 'fa' ? 'دروس در انتظار' : 'Disabled Subjects'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {disabledSubjects.map(([subject, config]) => (
                  <div 
                    key={subject}
                    className="flex items-center justify-between p-3 border rounded-lg opacity-60"
                  >
                    <div>
                      <div className="font-medium">{subject}</div>
                      {config.customMessage && (
                        <div className="text-xs text-muted-foreground">
                          {language === 'fa' ? config.customMessage.fa : config.customMessage.en}
                        </div>
                      )}
                    </div>
                    <Badge variant="secondary">
                      {language === 'fa' ? 'غیرفعال' : 'Disabled'}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* راهنما */}
          <Card className="bg-blue-50 dark:bg-blue-950">
            <CardContent className="p-4">
              <div className="text-sm">
                <h4 className="font-medium mb-2">
                  {language === 'fa' ? '📝 راهنمای استفاده:' : '📝 Usage Guide:'}
                </h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>
                    {language === 'fa' 
                      ? '• برای اضافه کردن جزوه: درس را انتخاب کنید و تعداد جزوه‌های موجود را وارد کنید'
                      : '• To add notebooks: Select subject and enter available notebook count'
                    }
                  </li>
                  <li>
                    {language === 'fa'
                      ? '• جزوه‌های اضافی به صورت "به زودی" نمایش داده می‌شوند'
                      : '• Additional notebooks will show as "Coming Soon"'
                    }
                  </li>
                  <li>
                    {language === 'fa'
                      ? '• برای فعال کردن درس: تعداد بیشتر از 0 وارد کنید'
                      : '• To enable a subject: Enter count greater than 0'
                    }
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}