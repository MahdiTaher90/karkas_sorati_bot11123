import { useState, useEffect, useMemo } from 'react';
import { SearchBox } from './SearchBox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ExternalLink, FileText, Download, AlertCircle } from 'lucide-react';
import { useLanguage } from './LanguageProvider';

interface CSVNotebook {
  file_name: string;
  subject: string;
  drive_link: string;
}

interface CSVNotebooksPageProps {
  subjectName: string;
  csvData: { [subject: string]: { file_name: string; subject: string; drive_link: string; }[] };
}

export function CSVNotebooksPage({ subjectName, csvData }: CSVNotebooksPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [notebooks, setNotebooks] = useState<CSVNotebook[]>([]);
  const { language } = useLanguage();

  // تبدیل داده‌های CSV به فرمت notebook
  useEffect(() => {
    const subjectFiles = csvData[subjectName] || [];
    const convertedNotebooks: CSVNotebook[] = subjectFiles.map(file => ({
      file_name: file.file_name,
      subject: file.subject,
      drive_link: file.drive_link
    }));
    setNotebooks(convertedNotebooks);
  }, [subjectName, csvData]);

  // فیلتر کردن جزوه‌ها بر اساس جست‌وجو
  const filteredNotebooks = useMemo(() => {
    if (!searchTerm.trim()) return notebooks;
    
    const term = searchTerm.toLowerCase();
    return notebooks.filter(notebook =>
      notebook.file_name.toLowerCase().includes(term) ||
      notebook.subject.toLowerCase().includes(term)
    );
  }, [notebooks, searchTerm]);

  const openInDrive = (driveLink: string) => {
    window.open(driveLink, '_blank', 'noopener,noreferrer');
  };

  const downloadFile = (driveLink: string, fileName: string) => {
    // استخراج file ID از لینک Google Drive
    const fileIdMatch = driveLink.match(/\/d\/([a-zA-Z0-9-_]+)/);
    if (fileIdMatch) {
      const fileId = fileIdMatch[1];
      const downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  if (notebooks.length === 0) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">
              {language === 'fa' ? 'هیچ جزوه‌ای موجود نیست' : 'No notebooks available'}
            </h3>
            <p className="text-muted-foreground text-center">
              {language === 'fa' 
                ? 'برای این موضوع هنوز جزوه‌ای در CSV یافت نشد'
                : 'No notebooks found for this subject in the CSV data'
              }
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* جعبه جست‌وجو */}
      <SearchBox
        value={searchTerm}
        onChange={setSearchTerm}
        placeholder={language === 'fa' ? 'جست‌وجو در جزوه‌ها...' : 'Search notebooks...'}
      />

      {/* آمار */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{notebooks.length}</div>
            <div className="text-sm text-muted-foreground">
              {language === 'fa' ? 'کل جزوه‌ها' : 'Total Notebooks'}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-accent-foreground">{filteredNotebooks.length}</div>
            <div className="text-sm text-muted-foreground">
              {language === 'fa' ? 'نتایج جست‌وجو' : 'Search Results'}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-2 md:col-span-1">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-chart-3">{subjectName}</div>
            <div className="text-sm text-muted-foreground">
              {language === 'fa' ? 'موضوع فعلی' : 'Current Subject'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* لیست جزوه‌ها */}
      <div className="grid gap-4">
        {filteredNotebooks.map((notebook, index) => (
          <Card key={`${notebook.file_name}-${index}`} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary flex-shrink-0" />
                  <CardTitle className="text-base">{notebook.file_name}</CardTitle>
                </div>
                <Badge variant="secondary" className="w-fit">
                  {notebook.subject}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() => openInDrive(notebook.drive_link)}
                  className="flex items-center gap-2"
                  size="sm"
                >
                  <ExternalLink className="h-4 w-4" />
                  {language === 'fa' ? 'مشاهده در Drive' : 'View in Drive'}
                </Button>
                <Button
                  onClick={() => downloadFile(notebook.drive_link, notebook.file_name)}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  {language === 'fa' ? 'دانلود' : 'Download'}
                </Button>
              </div>
              <div className="mt-3 text-xs text-muted-foreground">
                {language === 'fa' ? 'لینک Drive: ' : 'Drive Link: '}
                <code className="bg-muted px-1 py-0.5 rounded text-xs break-all">
                  {notebook.drive_link}
                </code>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredNotebooks.length === 0 && searchTerm && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-8">
            <AlertCircle className="h-8 w-8 text-muted-foreground mb-3" />
            <h3 className="font-medium mb-2">
              {language === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found'}
            </h3>
            <p className="text-sm text-muted-foreground text-center">
              {language === 'fa' 
                ? `برای "${searchTerm}" نتیجه‌ای یافت نشد. کلمات کلیدی دیگری امتحان کنید.`
                : `No results found for "${searchTerm}". Try different keywords.`
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}