import { useLanguage } from './LanguageProvider';
import { Card, CardContent } from './ui/card';
import { BookOpen, Calendar, Sparkles } from 'lucide-react';

interface MainMenuProps {
  onSelectNotebooks: () => void;
  onSelectScheduler: () => void;
}

export function MainMenu({ onSelectNotebooks, onSelectScheduler }: MainMenuProps) {
  const { language, t } = useLanguage();

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="text-center space-y-2">
        <h1>{t('welcome')}</h1>
        <p className="text-muted-foreground">
          {t('welcomeDescription')}
        </p>
      </div>

      {/* Menu Options */}
      <div className="grid gap-4 md:grid-cols-2 max-w-2xl mx-auto">
        {/* Study Notebooks */}
        <Card 
          className="cursor-pointer transition-all hover:shadow-lg hover:scale-105 border-2 hover:border-primary/20 bg-gradient-to-br from-card to-pink-50/50 dark:from-card dark:to-pink-900/10"
          onClick={onSelectNotebooks}
        >
          <CardContent className="p-6 text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-3 bg-primary/10 dark:bg-primary/20 rounded-full border border-primary/20">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
            </div>
            <div className="space-y-2">
              <h3>{t('studyNotebooks')}</h3>
              <p className="text-sm text-muted-foreground font-bold font-normal">
                {language === 'fa' 
                  ? 'دسترسی به جزوات'
                  : 'Access study notebooks'
                }
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Schedule Planner */}
        <Card 
          className="cursor-pointer transition-all hover:shadow-lg hover:scale-105 border-2 hover:border-primary/20 bg-gradient-to-br from-card to-amber-50/50 dark:from-card dark:to-amber-900/10"
          onClick={onSelectScheduler}
        >
          <CardContent className="p-6 text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-3 bg-accent/20 dark:bg-accent/30 rounded-full border border-accent/30">
                <div className="relative">
                  <Calendar className="h-8 w-8 text-accent-foreground" />
                  <Sparkles className="h-4 w-4 text-accent-foreground absolute -top-1 -right-1" />
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <h3>{t('schedulePlanner')}</h3>
              <p className="text-sm text-muted-foreground">
                {language === 'fa' 
                  ? 'ساخت برنامه هفتگی شخصی‌سازی شده'
                  : 'Create personalized weekly schedule'
                }
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}