import { SubjectSelector, Subject } from './SubjectSelector';
import { useLanguage } from './LanguageProvider';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { RefreshCw } from 'lucide-react';

interface SubjectSelectionPageProps {
  subjects: Subject[];
  onSelectSubject: (subjectId: string) => void;
  loading?: boolean;
  onRefresh?: () => void;
}

export function SubjectSelectionPage({ subjects, onSelectSubject, loading = false, onRefresh }: SubjectSelectionPageProps) {
  const { language } = useLanguage();

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="text-center space-y-4">
          <h2 className="text-3xl">
            {language === 'fa' ? 'کرکس صورتی' : 'Pink Vulture'}
          </h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            {language === 'fa' ? 'در حال بارگذاری جزوه‌ها...' : 'Loading notebooks...'}
          </p>
        </div>
        
        <Card className="max-w-md mx-auto">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <RefreshCw className="h-8 w-8 animate-spin text-primary mb-4" />
            <p className="text-muted-foreground">
              {language === 'fa' ? 'در جست و جوی جزوه ...' : 'Loading Data ...'}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (subjects.length === 0) {
    return (
      <div className="space-y-8">
        <div className="text-center space-y-4">
          <h2 className="text-3xl">
            {language === 'fa' ? 'کرکس صورتی' : 'Pink Vulture'}
          </h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            {language === 'fa' ? 'هیچ موضوعی موجود نیست' : 'No subjects available'}
          </p>
          {onRefresh && (
            <Button onClick={onRefresh} variant="outline" className="gap-2">
              <RefreshCw className="h-4 w-4" />
              {language === 'fa' ? 'بارگذاری مجدد' : 'Reload'}
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-3xl">
          {language === 'fa' ? 'انتخاب موضوع درسی' : 'Select Subject'}
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          {language === 'fa' 
            ? 'موضوع مورد نظر خود را برای مشاهده جزوه‌ها انتخاب کنید'
            : 'Choose your subject to view available notebooks'
          }
        </p>
      </div>
      
      <div className="max-w-4xl mx-auto">
        <SubjectSelector
          subjects={subjects}
          selectedSubject={null}
          onSelectSubject={(subjectId) => {
            if (subjectId) {
              onSelectSubject(subjectId);
            }
          }}
        />
      </div>
    </div>
  );
}