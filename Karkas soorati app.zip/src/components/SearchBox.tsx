import { Search } from 'lucide-react';
import { Input } from './ui/input';
import { useLanguage } from './LanguageProvider';

interface SearchBoxProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function SearchBox({ value, onChange, placeholder }: SearchBoxProps) {
  const { language, t } = useLanguage();
  const defaultPlaceholder = placeholder || t('searchPlaceholder');
  const isRTL = language === 'fa';

  return (
    <div className="relative">
      <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
      <Input
        type="text"
        placeholder={defaultPlaceholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={isRTL ? "pr-10" : "pl-10"}
        dir={isRTL ? "rtl" : "ltr"}
      />
    </div>
  );
}