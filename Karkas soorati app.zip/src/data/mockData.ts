import { Subject } from '../components/SubjectSelector';
import { Notebook } from '../components/NotebookCard';
import { contentConfig, isNotebookAvailable, getSubjectStatus } from './contentConfig';

// تولید لیست هفته‌های سال تحصیلی با تاریخ مناسب
const generateWeeksList = () => {
  const months = [
    { name: 'مهر', nameEn: 'Mehr', weeks: 4, monthNumber: 7 },
    { name: 'آبان', nameEn: 'Aban', weeks: 4, monthNumber: 8 },
    { name: 'آذر', nameEn: 'Azar', weeks: 4, monthNumber: 9 },
    { name: 'دی', nameEn: 'Dey', weeks: 4, monthNumber: 10 },
    { name: 'بهمن', nameEn: 'Bahman', weeks: 4, monthNumber: 11 },
    { name: 'اسفند', nameEn: 'Esfand', weeks: 4, monthNumber: 12 },
    { name: 'فروردین', nameEn: 'Farvardin', weeks: 4, monthNumber: 1 },
    { name: 'اردیبهشت', nameEn: 'Ordibehesht', weeks: 4, monthNumber: 2 },
    { name: 'خرداد', nameEn: 'Khordad', weeks: 3, monthNumber: 3 }
  ];

  const weeks = [];
  const weekNumbers = ['اول', 'دوم', 'سوم', 'چهارم'];
  const weekNumbersEn = ['First', 'Second', 'Third', 'Fourth'];

  months.forEach(month => {
    for (let i = 0; i < month.weeks; i++) {
      // محاسبه تاریخ برای هر هفته
      const day = (i + 1) * 7; // هفته اول = روز 7، هفته دوم = روز 14، ...
      const year = month.monthNumber >= 7 ? 1404 : 1405; // سال تحصیلی 1404-1405 (مهر تا اسفند = 1404، فروردین تا خرداد = 1405)
      const persianDate = `${year}/${month.monthNumber.toString().padStart(2, '0')}/${day.toString().padStart(2, '0')}`;
      
      weeks.push({
        title: `هفته ${weekNumbers[i]} ${month.name}`,
        titleEn: `${weekNumbersEn[i]} Week of ${month.nameEn}`,
        date: persianDate
      });
    }
  });

  return weeks;
};

const academicWeeks = generateWeeksList();

// آپدیت subjects با اطلاعات واقعی از contentConfig
export const subjects: Subject[] = [
  { 
    id: 'math', 
    name: 'ریاضی', 
    nameEn: 'Mathematics', 
    notebookCount: contentConfig['ریاضی']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('ریاضی')
  },
  { 
    id: 'physics', 
    name: 'فیزیک', 
    nameEn: 'Physics', 
    notebookCount: contentConfig['فیزیک']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('فیزیک')
  },
  { 
    id: 'chemistry', 
    name: 'شیمی', 
    nameEn: 'Chemistry', 
    notebookCount: contentConfig['شیمی']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('شیمی')
  },
  { 
    id: 'biology', 
    name: 'زیست‌شناسی', 
    nameEn: 'Biology', 
    notebookCount: contentConfig['زیست‌شناسی']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('زیست‌شناسی')
  },

  { 
    id: 'computer', 
    name: 'کامپیوتر', 
    nameEn: 'Computer Science', 
    notebookCount: contentConfig['کامپیوتر']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('کامپیوتر')
  },
  { 
    id: 'algebra', 
    name: 'جبر', 
    nameEn: 'Algebra', 
    notebookCount: contentConfig['جبر']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('جبر')
  },
  { 
    id: 'olympiad-astronomy', 
    name: 'المپیاد نجوم', 
    nameEn: 'Astronomy Olympiad', 
    notebookCount: contentConfig['المپیاد نجوم']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('المپیاد نجوم')
  },
  { 
    id: 'olympiad-physics', 
    name: 'المپیاد فیزیک', 
    nameEn: 'Physics Olympiad', 
    notebookCount: contentConfig['المپیاد فیزیک']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('المپیاد فیزیک')
  },
  { 
    id: 'olympiad-math', 
    name: 'المپیاد ریاضی', 
    nameEn: 'Mathematics Olympiad', 
    notebookCount: contentConfig['المپیاد ریاضی']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('المپیاد ریاضی')
  },
  { 
    id: 'olympiad-computer', 
    name: 'المپیاد کامپیوتر', 
    nameEn: 'Computer Olympiad', 
    notebookCount: contentConfig['المپیاد کامپیوتر']?.availableNotebooks || 0,
    totalNotebooks: 35,
    status: getSubjectStatus('المپیاد کامپیوتر')
  }
].filter(subject => subject.status?.enabled !== false); // فقط دروس فعال نمایش داده شوند

// تولید notebooks بر اساس تنظیمات محتوا
const generateNotebooksForSubject = (subjectName: string, startId: number): Notebook[] => {
  const config = getSubjectStatus(subjectName);
  if (!config || !config.enabled) return [];
  
  return academicWeeks.map((week, index) => {
    const isAvailable = isNotebookAvailable(subjectName, index);
    
    return {
      id: `${subjectName.toLowerCase().replace(/\s+/g, '-')}-${startId + index}`,
      title: week.title,
      titleEn: week.titleEn,
      subject: subjectName,
      description: isAvailable 
        ? getSubjectDescription(subjectName, week.title)
        : (config.customMessage?.fa || 'به زودی منتشر می‌شود'),
      descriptionEn: isAvailable 
        ? getSubjectDescriptionEn(subjectName, week.titleEn)
        : (config.customMessage?.en || 'Coming soon'),
      driveLink: isAvailable 
        ? `https://drive.google.com/file/d/real-${subjectName}-week-${index + 1}/view`
        : null, // جزوه‌های غیرموجود لینک ندارند
      createdAt: week.date,
      pages: isAvailable ? Math.floor(Math.random() * 35) + 20 : 0,
      fileSize: isAvailable ? `${(Math.random() * 2.5 + 1.5).toFixed(1)} MB` : null,
      isAvailable,
      isComingSoon: !isAvailable
    };
  });
};

// توضیحات دروس
function getSubjectDescription(subject: string, week: string): string {
  const descriptions: Record<string, string> = {
    'ریاضی': `مطالب ریاضی تخصصی برای ${week} شامل تحلیل، جبر و هندسه`,
    'فیزیک': `مطالب فیزیک پیشرفته برای ${week} شامل مکانیک، الکتریسیته و نور`,
    'شیمی': `مطالب شیمی کاربردی برای ${week} شامل شیمی آلی، معدنی و فیزیکی`,
    'زیست‌شناسی': `مطالب زیست‌شناسی جامع برای ${week} شامل بیولوژی سلولی، ژنتیک و فیزیولوژی`,

    'کامپیوتر': `مطالب علوم کامپیوتر برای ${week} شامل برنامه‌نویسی، الگوریتم و پایگاه داده`,
    'جبر': `مطالب جبر پیشرفته برای ${week} شامل جبر خطی، تجرید و نظریه گروه`,
    'المپیاد نجوم': `مطالب تخصصی نجوم و اخترفیزیک برای ${week}`,
    'المپیاد فیزیک': `مسائل پیشرفته فیزیک و تکنیک‌های حل برای ${week}`,
    'المپیاد ریاضی': `مسائل چالش‌برانگیز ریاضی و روش‌های حل خلاقانه برای ${week}`,
    'المپیاد کامپیوتر': `الگوریتم‌ها، ساختار داده و برنامه‌نویسی پیشرفته برای ${week}`
  };
  return descriptions[subject] || `محتوای ${subject} برای ${week}`;
}

function getSubjectDescriptionEn(subject: string, week: string): string {
  const descriptions: Record<string, string> = {
    'ریاضی': `Specialized mathematics content for ${week} including analysis, algebra and geometry`,
    'فیزیک': `Advanced physics content for ${week} including mechanics, electricity and optics`,
    'شیمی': `Applied chemistry content for ${week} including organic, inorganic and physical chemistry`,
    'زیست‌شناسی': `Comprehensive biology content for ${week} including cell biology, genetics and physiology`,

    'کامپیوتر': `Computer science content for ${week} including programming, algorithms and databases`,
    'جبر': `Advanced algebra content for ${week} including linear algebra, abstract algebra and group theory`,
    'المپیاد نجوم': `Specialized astronomy and astrophysics content for ${week}`,
    'المپیاد فیزیک': `Advanced physics problems and solving techniques for ${week}`,
    'المپیاد ریاضی': `Challenging mathematical problems and creative solving methods for ${week}`,
    'المپیاد کامپیوتر': `Algorithms, data structures and advanced programming for ${week}`
  };
  return descriptions[subject] || `${subject} content for ${week}`;
}

export const notebooks: Notebook[] = [
  ...generateNotebooksForSubject('ریاضی', 1),
  ...generateNotebooksForSubject('فیزیک', 36),
  ...generateNotebooksForSubject('شیمی', 71),
  ...generateNotebooksForSubject('زیست‌شناسی', 106),
  ...generateNotebooksForSubject('کامپیوتر', 141),
  ...generateNotebooksForSubject('جبر', 176),
  ...generateNotebooksForSubject('المپیاد نجوم', 211),
  ...generateNotebooksForSubject('المپیاد فیزیک', 246),
  ...generateNotebooksForSubject('المپیاد ریاضی', 281),
  ...generateNotebooksForSubject('المپیاد کامپیوتر', 316)
].filter(notebook => notebook.subject && getSubjectStatus(notebook.subject)?.enabled);