import { useLanguage } from './LanguageProvider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { HelpCircle, FolderOpen, Upload, Link, Copy, CheckCircle } from 'lucide-react';

export function DriveGuide() {
  const { language } = useLanguage();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <HelpCircle className="h-4 w-4" />
          {language === 'fa' ? 'راهنما' : 'Guide'}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5" />
            {language === 'fa' ? 'راهنمای کار با گوگل درایو' : 'Google Drive Integration Guide'}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="scan" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="scan">
              {language === 'fa' ? 'اسکن محتوا' : 'Content Scan'}
            </TabsTrigger>
            <TabsTrigger value="organize">
              {language === 'fa' ? 'سازماندهی' : 'Organization'}
            </TabsTrigger>
            <TabsTrigger value="tips">
              {language === 'fa' ? 'نکات مفید' : 'Tips'}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scan" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  {language === 'fa' ? 'نحوه اسکن محتوای درایو' : 'How to Scan Drive Content'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {language === 'fa' ? (
                  <>
                    <div className="space-y-2">
                      <h4 className="font-medium">مرحله 1: دسترسی به پوشه درس</h4>
                      <p className="text-sm text-muted-foreground">
                        به گوگل درایو بروید و پوشه مربوط به هر درس را باز کنید.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium">مرحله 2: کپی کردن لیست فایل‌ها</h4>
                      <p className="text-sm text-muted-foreground">
                        تمام فایل‌های موجود در پوشه را انتخاب کنید (Ctrl+A) و سپس نام‌هایشان را کپی کنید.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium">مرحله 3: وارد کردن در اسکنر</h4>
                      <p className="text-sm text-muted-foreground">
                        متن کپی شده را در کادر "اسکن درایو" paste کنید و روی "تحلیل محتوا" کلیک کنید.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <h4 className="font-medium">Step 1: Access Subject Folder</h4>
                      <p className="text-sm text-muted-foreground">
                        Go to Google Drive and open the folder for each subject.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium">Step 2: Copy File List</h4>
                      <p className="text-sm text-muted-foreground">
                        Select all files in the folder (Ctrl+A) and copy their names.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium">Step 3: Input to Scanner</h4>
                      <p className="text-sm text-muted-foreground">
                        Paste the copied text into the "Drive Scanner" box and click "Analyze Content".
                      </p>
                    </div>
                  </>
                )}

                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    {language === 'fa' 
                      ? 'سیستم به طور خودکار تعداد جزوه‌های هر درس را می‌شمارد و تنظیمات را به‌روزرسانی می‌کند.'
                      : 'The system automatically counts notebooks for each subject and updates settings.'
                    }
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>
                  {language === 'fa' ? 'فرمت‌های پشتیبانی شده' : 'Supported Formats'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h5 className="font-medium">
                      {language === 'fa' ? 'فرمت ساختاریافته:' : 'Structured Format:'}
                    </h5>
                    <div className="bg-muted p-3 rounded mt-2 font-mono text-sm">
                      <div>ریاضی: 5</div>
                      <div>فیزیک: 3</div>
                      <div>شیمی: 2</div>
                    </div>
                  </div>
                  
                  <div>
                    <h5 className="font-medium">
                      {language === 'fa' ? 'لیست فایل‌ها:' : 'File List:'}
                    </h5>
                    <div className="bg-muted p-3 rounded mt-2 font-mono text-sm">
                      <div>math-week1.pdf</div>
                      <div>math-week2.pdf</div>
                      <div>physics-week1.pdf</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="organize" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FolderOpen className="h-5 w-5" />
                  {language === 'fa' ? 'سازماندهی پوشه‌ها' : 'Folder Organization'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {language === 'fa' ? (
                  <>
                    <div>
                      <h4 className="font-medium mb-2">ساختار پیشنهادی:</h4>
                      <div className="bg-muted p-4 rounded font-mono text-sm">
                        📁 کرکس صورتی<br />
                        ├── 📁 ریاضی<br />
                        │   ├── 📄 هفته اول مهر.pdf<br />
                        │   ├── 📄 هفته دوم مهر.pdf<br />
                        │   └── ...<br />
                        ├── 📁 فیزیک<br />
                        │   ├── 📄 هفته اول مهر.pdf<br />
                        │   └── ...<br />
                        └── 📁 سایر دروس
                      </div>
                    </div>
                    
                    <Alert>
                      <FolderOpen className="h-4 w-4" />
                      <AlertDescription>
                        نام‌گذاری فایل‌ها بر اساس هفته‌های سال تحصیلی باعث مرتب‌سازی بهتر می‌شود.
                      </AlertDescription>
                    </Alert>
                  </>
                ) : (
                  <>
                    <div>
                      <h4 className="font-medium mb-2">Recommended Structure:</h4>
                      <div className="bg-muted p-4 rounded font-mono text-sm">
                        📁 Pink Vulture<br />
                        ├── 📁 Mathematics<br />
                        │   ├── 📄 Week 1 Mehr.pdf<br />
                        │   ├── 📄 Week 2 Mehr.pdf<br />
                        │   └── ...<br />
                        ├── 📁 Physics<br />
                        │   ├── 📄 Week 1 Mehr.pdf<br />
                        │   └── ...<br />
                        └── 📁 Other Subjects
                      </div>
                    </div>
                    
                    <Alert>
                      <FolderOpen className="h-4 w-4" />
                      <AlertDescription>
                        Naming files based on academic weeks helps with better organization.
                      </AlertDescription>
                    </Alert>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tips" className="space-y-4">
            <div className="grid gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>
                    {language === 'fa' ? '💡 نکات کاربردی' : '💡 Practical Tips'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {language === 'fa' ? (
                    <>
                      <div className="flex items-start gap-3">
                        <span className="text-green-600">✓</span>
                        <div>
                          <h5 className="font-medium">نام‌گذاری یکنواخت</h5>
                          <p className="text-sm text-muted-foreground">
                            از الگوی ثابت برای نام‌گذاری فایل‌ها استفاده کنید تا سیستم بهتر شناسایی کند.
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <span className="text-green-600">✓</span>
                        <div>
                          <h5 className="font-medium">بک‌آپ منظم</h5>
                          <p className="text-sm text-muted-foreground">
                            به طور منظم از فایل‌های مهم بک‌آپ تهیه کنید.
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <span className="text-green-600">✓</span>
                        <div>
                          <h5 className="font-medium">بررسی دوره‌ای</h5>
                          <p className="text-sm text-muted-foreground">
                            هفته‌ای یکبار محتوای جدید را اسکن کنید.
                          </p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-start gap-3">
                        <span className="text-green-600">✓</span>
                        <div>
                          <h5 className="font-medium">Consistent Naming</h5>
                          <p className="text-sm text-muted-foreground">
                            Use a consistent pattern for file naming for better recognition.
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <span className="text-green-600">✓</span>
                        <div>
                          <h5 className="font-medium">Regular Backup</h5>
                          <p className="text-sm text-muted-foreground">
                            Regularly backup important files.
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <span className="text-green-600">✓</span>
                        <div>
                          <h5 className="font-medium">Periodic Review</h5>
                          <p className="text-sm text-muted-foreground">
                            Scan for new content weekly.
                          </p>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>
                    {language === 'fa' ? '🔗 نمونه لینک‌ها' : '🔗 Sample Links'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2">
                    <code className="flex-1 bg-muted p-2 rounded text-sm">
                      https://drive.google.com/file/d/1ABC.../view
                    </code>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => copyToClipboard('https://drive.google.com/file/d/1ABC.../view')}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <code className="flex-1 bg-muted p-2 rounded text-sm">
                      https://drive.google.com/drive/folders/1XYZ...
                    </code>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => copyToClipboard('https://drive.google.com/drive/folders/1XYZ...')}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}