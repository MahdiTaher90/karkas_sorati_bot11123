import { useState, useMemo } from 'react';
import { SearchBox } from './SearchBox';
import { NotebooksList } from './NotebooksList';
import { Notebook } from './NotebookCard';
import { Separator } from './ui/separator';
import { useLanguage } from './LanguageProvider';

interface NotebooksPageProps {
  notebooks: Notebook[];
  subjectName: string;
}

export function NotebooksPage({ notebooks, subjectName }: NotebooksPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { t } = useLanguage();

  const filteredNotebooks = useMemo(() => {
    if (!searchQuery.trim()) {
      return notebooks;
    }

    const query = searchQuery.toLowerCase().trim();
    return notebooks.filter(notebook => 
      notebook.title.toLowerCase().includes(query) ||
      (notebook.description && notebook.description.toLowerCase().includes(query))
    );
  }, [notebooks, searchQuery]);

  const isSearching = searchQuery.trim().length > 0;

  return (
    <div className="space-y-8">
      {/* جست‌وجو */}
      <div className="max-w-md mx-auto">
        <SearchBox
          value={searchQuery}
          onChange={setSearchQuery}
          placeholder={`${t('searchInSubject')} ${subjectName}...`}
        />
      </div>

      <Separator />

      {/* لیست جزوه‌ها */}
      <NotebooksList 
        notebooks={filteredNotebooks}
        isSearching={isSearching}
        searchQuery={searchQuery}
      />
    </div>
  );
}