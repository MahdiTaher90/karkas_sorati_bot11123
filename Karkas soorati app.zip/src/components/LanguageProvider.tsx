import React, { createContext, useContext, useEffect, useState } from 'react';

type Language = 'fa' | 'en';

interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  fa: {
    appName: 'کرکس صورتی',
    welcome: 'به اپلیکیشن کرکس صورتی خوش آمدید',
    welcomeDescription: 'یکی از امکانات زیر را انتخاب کنید',
    availableSubjects: 'دروس موجود',
    selectSubjectDescription: 'روی هر درس کلیک کنید تا جزوه‌های آن را مشاهده کنید',
    searchPlaceholder: 'جست‌وجو در جزوه‌ها...',
    searchInSubject: 'جست‌وجو در جزوه‌های',
    searchResults: 'نتایج جست‌وجو برای',
    notebooks: 'جزوه‌ها',
    notebookCount: 'جزوه',
    noNotebooksFound: 'هیچ جزوه‌ای یافت نشد.',
    noSearchResults: 'هیچ جزوه‌ای برای',
    viewInGoogleDrive: 'مشاهده در گوگل درایو',
    pages: 'صفحه',
    themeToggle: 'تغییر تم',
    languageToggle: 'English',
    schedulePlanner: 'ربات برنامه‌ریز',
    schedulePlannerDescription: 'برنامه هفتگی شخصی‌سازی شده با هوش مصنوعی بسازید',
    enterActivities: 'فعالیت‌های خود را وارد کنید',
    scheduleInputGuide: 'ساعت بیداری و خواب را در خط اول و آخر بنویسید. فعالیت‌ها را با زمان (مثل: ورزش 7 تا 8) یا بدون زمان وارد کنید.',
    generateSchedule: 'تولید برنامه',
    generating: 'در حال تولید...',
    clear: 'پاک کردن',
    generatedSchedule: 'برنامه تولید شده',
    home: 'خانه',
    studyNotebooks: 'جزوه‌های درسی',
    refresh: 'بارگذاری مجدد',
  },
  en: {
    appName: 'Pink Vulture',
    welcome: 'Welcome to Pink Vulture app',
    welcomeDescription: 'Choose one of the options below',
    availableSubjects: 'Available Subjects',
    selectSubjectDescription: 'Click on any subject to view its notebooks',
    searchPlaceholder: 'Search in notebooks...',
    searchInSubject: 'Search in notebooks of',
    searchResults: 'Search results for',
    notebooks: 'Notebooks',
    notebookCount: 'notebook',
    noNotebooksFound: 'No notebooks found.',
    noSearchResults: 'No notebooks found for',
    viewInGoogleDrive: 'View in Google Drive',
    pages: 'pages',
    themeToggle: 'Toggle theme',
    languageToggle: 'فارسی',
    schedulePlanner: 'Schedule Planner Bot',
    schedulePlannerDescription: 'Create a personalized weekly schedule with AI',
    enterActivities: 'Enter Your Activities',
    scheduleInputGuide: 'Write wake-up and sleep times in first and last lines. Enter activities with time (e.g.: exercise 7 to 8) or without time.',
    generateSchedule: 'Generate Schedule',
    generating: 'Generating...',
    clear: 'Clear',
    generatedSchedule: 'Generated Schedule',
    home: 'Home',
    studyNotebooks: 'Study Notebooks',
    refresh: 'Refresh',
  }
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('fa');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && (savedLanguage === 'fa' || savedLanguage === 'en')) {
      setLanguage(savedLanguage);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('language', language);
    document.documentElement.setAttribute('dir', language === 'fa' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', language);
  }, [language]);

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'fa' ? 'en' : 'fa');
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}