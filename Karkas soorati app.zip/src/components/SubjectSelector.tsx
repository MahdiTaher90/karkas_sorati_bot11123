import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from './LanguageProvider';

import { ContentStatus } from '../data/contentConfig';

export interface Subject {
  id: string;
  name: string;
  nameEn: string;
  notebookCount: number;
  totalNotebooks?: number;
  status?: ContentStatus | null;
}

interface SubjectSelectorProps {
  subjects: Subject[];
  selectedSubject: string | null;
  onSelectSubject: (subjectId: string | null) => void;
}

export function SubjectSelector({ subjects, selectedSubject, onSelectSubject }: SubjectSelectorProps) {
  const { language, t } = useLanguage();
  const ChevronIcon = language === 'fa' ? ChevronLeft : ChevronRight;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2>{t('availableSubjects')}</h2>
        <p className="text-sm text-muted-foreground mt-2">
          {t('selectSubjectDescription')}
        </p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map((subject) => (
          <Button
            key={subject.id}
            variant="outline"
            className="h-auto p-6 flex items-center justify-between hover:bg-primary/10 hover:border-primary/30 transition-all duration-200 rounded-[18px] group"
            onClick={() => onSelectSubject(subject.id)}
          >
            <div className="flex flex-col items-start gap-2">
              <span>{language === 'fa' ? subject.name : subject.nameEn}</span>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs bg-primary/10 text-primary border-primary/20">
                  {subject.notebookCount} {t('notebookCount')}
                </Badge>
                {subject.status?.customMessage && (
                  <Badge variant="outline" className="text-xs">
                    {language === 'fa' ? subject.status.customMessage.fa : subject.status.customMessage.en}
                  </Badge>
                )}
              </div>
            </div>
            <ChevronIcon className="h-4 w-4 text-accent group-hover:text-primary transition-colors" />
          </Button>
        ))}
      </div>
    </div>
  );
}