import { NotebookCard, Notebook } from './NotebookCard';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { useLanguage } from './LanguageProvider';

interface NotebooksListProps {
  notebooks: Notebook[];
  isSearching: boolean;
  searchQuery: string;
}

export function NotebooksList({ notebooks, isSearching, searchQuery }: NotebooksListProps) {
  const { t } = useLanguage();

  if (notebooks.length === 0) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          {isSearching 
            ? `${t('noSearchResults')} "${searchQuery}" ${t('noNotebooksFound')}`
            : t('noNotebooksFound')
          }
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2>
          {isSearching 
            ? `${t('searchResults')} "${searchQuery}"`
            : t('notebooks')
          }
        </h2>
        <span className="text-sm text-muted-foreground">
          {notebooks.length} {t('notebookCount')}
        </span>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {notebooks.map((notebook) => (
          <NotebookCard key={notebook.id} notebook={notebook} />
        ))}
      </div>
    </div>
  );
}