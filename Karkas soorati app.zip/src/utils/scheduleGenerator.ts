// تبدیل کد پایتون برنامه‌ریز به TypeScript

export interface ScheduleEntry {
  [time: string]: string;
}

export interface Schedule {
  [day: string]: ScheduleEntry;
}

export interface ParsedActivity {
  activity: string;
  start: number;
  end: number;
}

export interface ActivityResult {
  withTime: { [day: string]: ParsedActivity[] };
  noTime: { [day: string]: string[] };
}

const DAYS_FARSI = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه"];
const DAYS_ENGLISH = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

const DAY_MAP_FARSI: { [key: string]: string } = {
  'شنبه': 'شنبه',
  'یکشنبه': 'یکشنبه', 
  'دوشنبه': 'دوشنبه',
  'سه‌شنبه': 'سه‌شنبه',
  'چهارشنبه': 'چهارشنبه',
  'پنج‌شنبه': 'پنج‌شنبه',
  'جمعه': 'جمعه'
};

const DAY_MAP_ENGLISH: { [key: string]: string } = {
  'saturday': 'Saturday',
  'sunday': 'Sunday',
  'monday': 'Monday', 
  'tuesday': 'Tuesday',
  'wednesday': 'Wednesday',
  'thursday': 'Thursday',
  'friday': 'Friday',
  'sat': 'Saturday',
  'sun': 'Sunday', 
  'mon': 'Monday',
  'tue': 'Tuesday',
  'wed': 'Wednesday',
  'thu': 'Thursday',
  'fri': 'Friday'
};

const STOP_WORDS_FARSI = new Set(["هر", "روز", "تا"]);
const STOP_WORDS_ENGLISH = new Set(["every", "day", "to", "from", "and"]);

const EXTRA_ACTIVITIES_FARSI = ["مطالعه آزاد", "پیاده‌روی", "کسب مهارت", "درس", "درس"];
const EXTRA_ACTIVITIES_ENGLISH = ["Free Study", "Walking", "Skill Building", "Study", "Study"];

// Helper function to detect language
function detectLanguage(text: string): 'fa' | 'en' {
  const farsiChars = /[\u0600-\u06FF]/;
  return farsiChars.test(text) ? 'fa' : 'en';
}

// Helper function to get days based on language
function getDaysArray(language: 'fa' | 'en'): string[] {
  return language === 'fa' ? DAYS_FARSI : DAYS_ENGLISH;
}

// Helper function to expand day ranges
function expandDayRange(startDay: string, endDay: string, language: 'fa' | 'en'): string[] {
  const days = getDaysArray(language);
  const dayMap = language === 'fa' ? DAY_MAP_FARSI : DAY_MAP_ENGLISH;
  
  const normalizedStart = language === 'en' ? dayMap[startDay.toLowerCase()] : dayMap[startDay];
  const normalizedEnd = language === 'en' ? dayMap[endDay.toLowerCase()] : dayMap[endDay];
  
  const startIndex = days.indexOf(normalizedStart);
  const endIndex = days.indexOf(normalizedEnd);
  
  if (startIndex === -1 || endIndex === -1) return [];
  
  const result: string[] = [];
  if (startIndex <= endIndex) {
    for (let i = startIndex; i <= endIndex; i++) {
      result.push(days[i]);
    }
  } else {
    // Handle wrap-around (e.g., Friday to Monday)
    for (let i = startIndex; i < days.length; i++) {
      result.push(days[i]);
    }
    for (let i = 0; i <= endIndex; i++) {
      result.push(days[i]);
    }
  }
  
  return result;
}

export function buildEmptySchedule(wake: number = 6, sleep: number = 22, language: 'fa' | 'en' = 'fa'): Schedule {
  const schedule: Schedule = {};
  const times: string[] = [];
  
  // تولید تایم‌ها از wake تا sleep با فاصله 30 دقیقه - دقیقا مثل pandas date_range
  for (let hour = wake; hour < sleep; hour++) {
    times.push(`${hour.toString().padStart(2, '0')}:00`);
    times.push(`${hour.toString().padStart(2, '0')}:30`);
  }
  // اضافه کردن ساعت آخر
  times.push(`${sleep.toString().padStart(2, '0')}:00`);

  const days = getDaysArray(language);
  days.forEach(day => {
    schedule[day] = {};
    times.forEach(time => {
      schedule[day][time] = "Free";
    });
  });

  return schedule;
}

export function parseUserTextOffline(userText: string): ActivityResult {
  const language = detectLanguage(userText);
  const days = getDaysArray(language);
  const dayMap = language === 'fa' ? DAY_MAP_FARSI : DAY_MAP_ENGLISH;
  const stopWords = language === 'fa' ? STOP_WORDS_FARSI : STOP_WORDS_ENGLISH;
  
  const activitiesByDay: { [day: string]: ParsedActivity[] } = {};
  const noTimeActivities: { [day: string]: string[] } = {};

  // مقداردهی اولیه
  days.forEach(day => {
    activitiesByDay[day] = [];
    noTimeActivities[day] = [];
  });

  // الگوهای regex مختلف برای فرمت‌های مختلف
  const patterns = {
    // فرمت: "هر روز مدرسه 7 تا 14" یا "every day school 8 to 16"
    everyDayActivityTime: language === 'fa'
      ? /هر\s+روز\s+([\u0600-\u06FFa-zA-Z\s]+?)\s+(\d{1,2})\s*تا\s*(\d{1,2})/g
      : /every\s+day\s+([a-zA-Z\s]+?)\s+(\d{1,2})\s*(?:to|till|-)\s*(\d{1,2})/gi,
    
    // فرمت: "شنبه تا چهارشنبه مدرسه 7 تا 14" یا "Monday to Friday school 8 to 16"
    dayRangeActivityTime: language === 'fa'
      ? /([\u0600-\u06FF]+)\s*تا\s*([\u0600-\u06FF]+)\s+([\u0600-\u06FFa-zA-Z\s]+?)\s+(\d{1,2})\s*تا\s*(\d{1,2})/g
      : /([a-zA-Z]+)\s*(?:to|till|-)\s*([a-zA-Z]+)\s+([a-zA-Z\s]+?)\s+(\d{1,2})\s*(?:to|till|-)\s*(\d{1,2})/gi,
    
    // فرمت: "شنبه ورزش 8 تا 10" یا "Monday exercise 8 to 10"  
    dayActivityTime: language === 'fa'
      ? /([\u0600-\u06FF]+)\s+([\u0600-\u06FFa-zA-Z\s]+?)\s+(\d{1,2})\s*تا\s*(\d{1,2})/g
      : /([a-zA-Z]+)\s+([a-zA-Z\s]+?)\s+(\d{1,2})\s*(?:to|till|-)\s*(\d{1,2})/gi,
      
    // فرمت: "ریاضی 8 تا 10" یا "math 8 to 10"
    activityTime: language === 'fa' 
      ? /([\u0600-\u06FFa-zA-Z\s]+?)\s+(\d{1,2})\s*تا\s*(\d{1,2})/g
      : /([a-zA-Z\s]+?)\s+(\d{1,2})\s*(?:to|till|-)\s*(\d{1,2})/gi
  };

  const lines = userText.trim().split("\n");
  
  lines.forEach(line => {
    let processed = false;
    
    // بررسی فرمت "هر روز" + activity + time
    const everyDayMatches = Array.from(line.matchAll(patterns.everyDayActivityTime));
    if (everyDayMatches.length > 0) {
      everyDayMatches.forEach(match => {
        const activity = match[1].trim();
        const start = parseInt(match[2]);
        const end = parseInt(match[3]);
        
        days.forEach(day => {
          activitiesByDay[day].push({ activity, start, end });
        });
      });
      processed = true;
    }
    
    // بررسی فرمت day range + activity + time
    if (!processed) {
      const dayRangeMatches = Array.from(line.matchAll(patterns.dayRangeActivityTime));
      if (dayRangeMatches.length > 0) {
        dayRangeMatches.forEach(match => {
          const startDay = match[1].trim();
          const endDay = match[2].trim();
          const activity = match[3].trim();
          const start = parseInt(match[4]);
          const end = parseInt(match[5]);
          
          const expandedDays = expandDayRange(startDay, endDay, language);
          expandedDays.forEach(day => {
            activitiesByDay[day].push({ activity, start, end });
          });
        });
        processed = true;
      }
    }
    
    // بررسی فرمت day + activity + time
    if (!processed) {
      const dayActivityMatches = Array.from(line.matchAll(patterns.dayActivityTime));
      if (dayActivityMatches.length > 0) {
        dayActivityMatches.forEach(match => {
          const dayName = match[1].trim();
          const activity = match[2].trim();
          const start = parseInt(match[3]);
          const end = parseInt(match[4]);
          
          const normalizedDay = language === 'en' ? dayMap[dayName.toLowerCase()] : dayMap[dayName];
          if (normalizedDay) {
            activitiesByDay[normalizedDay].push({ activity, start, end });
          }
        });
        processed = true;
      }
    }
    
    // بررسی فرمت activity + time (بدون روز مشخص) یا با روز مشخص
    if (!processed) {
      let foundDay: string | null = null;
      
      // پیدا کردن روز در خط
      for (const [k, v] of Object.entries(dayMap)) {
        const searchKey = language === 'en' ? k : k;
        if (line.toLowerCase().includes(searchKey.toLowerCase())) {
          foundDay = v;
          break;
        }
      }

      const activityMatches = Array.from(line.matchAll(patterns.activityTime));
      
      if (activityMatches.length > 0) {
        activityMatches.forEach(match => {
          const activity = match[1].trim();
          const start = parseInt(match[2]);
          const end = parseInt(match[3]);
          
          if (foundDay) {
            activitiesByDay[foundDay].push({ activity, start, end });
          }
        });
        processed = true;
      }
    }
    
    // استخراج فعالیت‌های بدون زمان
    if (!processed) {
      let foundDay: string | null = null;
      
      // پیدا کردن روز در خط
      for (const [k, v] of Object.entries(dayMap)) {
        const searchKey = language === 'en' ? k : k;
        if (line.toLowerCase().includes(searchKey.toLowerCase())) {
          foundDay = v;
          break;
        }
      }
      
      // چک کردن آیا "هر روز" هست
      const isEveryDay = language === 'fa' ? line.includes("هر روز") : line.toLowerCase().includes("every day");
      
      const actPattern = language === 'fa' ? /([\u0600-\u06FFa-zA-Z]+)/g : /([a-zA-Z]+)/g;
      const acts = Array.from(line.matchAll(actPattern))
        .map(match => match[1].trim())
        .filter(act => !stopWords.has(act.toLowerCase()) && act.length > 1);

      if (acts.length > 0) {        
        if (isEveryDay) {
          days.forEach(d => {
            noTimeActivities[d].push(...acts);
          });
        } else if (foundDay) {
          noTimeActivities[foundDay].push(...acts);
        }
      }
    }
  });

  return { withTime: activitiesByDay, noTime: noTimeActivities };
}

export function fillSchedule(
  schedule: Schedule, 
  withTime: { [day: string]: ParsedActivity[] }, 
  noTime: { [day: string]: string[] }
): Schedule {
  const newSchedule = JSON.parse(JSON.stringify(schedule)); // Deep copy

  // پر کردن فعالیت‌های با زمان
  Object.entries(withTime).forEach(([day, activities]) => {
    activities.forEach(({ activity, start, end }) => {
      Object.keys(newSchedule[day]).forEach(time => {
        const hour = parseInt(time.split(':')[0]);
        if (start <= hour && hour < end) {
          newSchedule[day][time] = activity;
        }
      });
    });
  });

  // پر کردن فعالیت‌های بدون زمان
  Object.entries(noTime).forEach(([day, activities]) => {
    activities.forEach(activity => {
      const freeSlots = Object.keys(newSchedule[day]).filter(
        time => newSchedule[day][time] === "Free"
      );
      
      if (freeSlots.length >= 2) {
        const randomIndex = Math.floor(Math.random() * (freeSlots.length - 1));
        const chosenTime = freeSlots[randomIndex];
        const times = Object.keys(newSchedule[day]);
        const timeIndex = times.indexOf(chosenTime);
        
        if (timeIndex < times.length - 1) {
          newSchedule[day][times[timeIndex]] = activity;
          newSchedule[day][times[timeIndex + 1]] = activity;
        }
      }
    });
  });

  return newSchedule;
}

export function addRandomExtras(schedule: Schedule, language: 'fa' | 'en' = 'fa'): Schedule {
  const newSchedule = JSON.parse(JSON.stringify(schedule)); // Deep copy
  const days = getDaysArray(language);
  const extraActivities = language === 'fa' ? EXTRA_ACTIVITIES_FARSI : EXTRA_ACTIVITIES_ENGLISH;

  days.forEach(day => {
    if (!newSchedule[day]) return;
    
    const times = Object.keys(newSchedule[day]);
    const freeSlots = times.filter(time => newSchedule[day][time] === "Free");

    if (freeSlots.length < 4) return;

    const chosenTimes: number[] = [];
    let attempts = 0;
    const maxAttempts = 50; // جلوگیری از infinite loop

    while (chosenTimes.length < 2 && attempts < maxAttempts) {
      attempts++;
      const randomSlot = freeSlots[Math.floor(Math.random() * freeSlots.length)];
      const idx = times.indexOf(randomSlot);

      if (idx >= 0 && idx < times.length - 1) {
        if (newSchedule[day][times[idx]] === "Free" && 
            newSchedule[day][times[idx + 1]] === "Free") {
          
          // بررسی فاصله از سایر فعالیت‌ها
          const hasDistance = chosenTimes.length === 0 || 
            chosenTimes.every(prevIdx => Math.abs(idx - prevIdx) > 2);
          
          if (hasDistance) {
            chosenTimes.push(idx);
            // حذف این slot از freeSlots برای جلوگیری از تکرار
            const slotIndex = freeSlots.indexOf(randomSlot);
            if (slotIndex > -1) {
              freeSlots.splice(slotIndex, 1);
              if (idx + 1 < times.length) {
                const nextSlotIndex = freeSlots.indexOf(times[idx + 1]);
                if (nextSlotIndex > -1) {
                  freeSlots.splice(nextSlotIndex, 1);
                }
              }
            }
          }
        }
      }
    }

    chosenTimes.forEach(idx => {
      const activity = extraActivities[Math.floor(Math.random() * extraActivities.length)];
      newSchedule[day][times[idx]] = activity;
      if (idx + 1 < times.length) {
        newSchedule[day][times[idx + 1]] = activity;
      }
    });
  });

  return newSchedule;
}

export function fullFill(
  schedule: Schedule, 
  language: 'fa' | 'en' = 'fa',
  activities?: string[]
): Schedule {
  const newSchedule = JSON.parse(JSON.stringify(schedule)); // Deep copy
  const days = getDaysArray(language);
  
  const defaultActivities = activities || (language === 'fa' 
    ? ["درس", "درس", "Free", "خواب", "خواب کوتاه"]
    : ["Study", "Study", "Free", "Sleep", "Short nap"]);

  days.forEach(day => {
    if (!newSchedule[day]) return;
    
    Object.keys(newSchedule[day]).forEach(time => {
      if (newSchedule[day][time] === "Free") {
        const randomActivity = defaultActivities[Math.floor(Math.random() * defaultActivities.length)];
        // اگر "Free" انتخاب شد، همون "Free" باقی بمونه
        if (randomActivity !== "Free") {
          newSchedule[day][time] = randomActivity;
        }
      }
    });
  });

  return newSchedule;
}

export function buildSchedule(userText: string): Schedule {
  const language = detectLanguage(userText);
  const lines = userText.trim().split("\n");
  
  // بررسی و پارس کردن wake و sleep - دقیقا مثل کد پایتون
  let wake = 6;
  let sleep = 22;
  
  if (lines.length > 0) {
    const firstLine = lines[0].trim();
    const parsedWake = parseInt(firstLine);
    if (!isNaN(parsedWake) && parsedWake >= 0 && parsedWake <= 23) {
      wake = parsedWake;
    }
  }
  
  if (lines.length > 1) {
    const lastLine = lines[lines.length - 1].trim();
    const parsedSleep = parseInt(lastLine);
    if (!isNaN(parsedSleep) && parsedSleep >= 0 && parsedSleep <= 24 && parsedSleep > wake) {
      sleep = parsedSleep;
    }
  }
  
  let schedule = buildEmptySchedule(wake, sleep, language);
  const { withTime, noTime } = parseUserTextOffline(userText);
  
  schedule = fillSchedule(schedule, withTime, noTime);
  schedule = addRandomExtras(schedule, language);
  schedule = fullFill(schedule, language);
  
  return schedule;
}