import { ExternalLink, FileText, Calendar, Download } from 'lucide-react';
import { Card, CardContent, CardFooter } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useLanguage } from './LanguageProvider';

export interface Notebook {
  id: string;
  title: string;
  titleEn: string;
  subject: string;
  description?: string;
  descriptionEn?: string;
  driveLink: string | null;
  createdAt: string;
  pages?: number;
  fileSize?: string | null;
  isAvailable?: boolean;
  isComingSoon?: boolean;
}

interface NotebookCardProps {
  notebook: Notebook;
}

export function NotebookCard({ notebook }: NotebookCardProps) {
  const { language, t } = useLanguage();

  const openInGoogleDrive = () => {
    if (notebook.driveLink && notebook.isAvailable) {
      window.open(notebook.driveLink, '_blank');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === 'fa' ? 'fa-IR' : 'en-US');
  };

  return (
    <Card className={`transition-all border-l-4 ${notebook.isAvailable ? 'hover:shadow-md border-l-primary/40 hover:border-l-primary' : 'opacity-60 border-l-muted'}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-lg border ${notebook.isAvailable ? 'bg-primary/10 border-primary/20' : 'bg-muted border-muted'}`}>
            <FileText className={`h-5 w-5 ${notebook.isAvailable ? 'text-primary' : 'text-muted-foreground'}`} />
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-medium truncate">
              {language === 'fa' ? notebook.title : notebook.titleEn}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className="text-xs bg-primary/5 text-primary border-primary/20">
                {notebook.subject}
              </Badge>
              {notebook.isComingSoon && (
                <Badge variant="secondary" className="text-xs">
                  {language === 'fa' ? 'به زودی' : 'Coming Soon'}
                </Badge>
              )}
            </div>
            
            {(notebook.description || notebook.descriptionEn) && (
              <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                {language === 'fa' ? notebook.description : notebook.descriptionEn}
              </p>
            )}
            
            <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {formatDate(notebook.createdAt)}
              </div>
              
              {notebook.pages && (
                <span>{notebook.pages} {t('pages')}</span>
              )}
              
              {notebook.fileSize && (
                <span>{notebook.fileSize}</span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <div className="flex gap-2 w-full">
          {notebook.isAvailable ? (
            <>
              <Button 
                onClick={openInGoogleDrive}
                className="flex-1 gap-2 bg-primary hover:bg-primary/90"
                size="sm"
              >
                <ExternalLink className="h-4 w-4" />
                {t('viewInGoogleDrive')}
              </Button>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={openInGoogleDrive}
                className="border-accent/50 hover:bg-accent/20 hover:text-accent-foreground"
              >
                <Download className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Button 
              disabled
              className="flex-1 gap-2"
              size="sm"
              variant="outline"
            >
              {language === 'fa' ? '🔒 به زودی منتشر می‌شود' : '🔒 Coming Soon'}
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}