import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { RefreshCw, Database, FileText, AlertCircle } from 'lucide-react';
import { useLanguage } from './LanguageProvider';
import { CSVStatusDisplay } from './CSVStatusDisplay';
import { CSVGuide } from './CSVGuide';

interface CSVRow {
  file_id: string;
  file_name: string;
  subject: string;
}

interface ProcessedData {
  [subject: string]: CSVRow[];
}

interface SubjectMapping {
  [csvSubject: string]: string;
}

interface CSVDataManagerProps {
  onDataLoaded?: (data: ProcessedData) => void;
  onSubjectSelect?: (subject: string, data: ProcessedData) => void;
}

export function CSVDataManager({ onDataLoaded, onSubjectSelect }: CSVDataManagerProps = {}) {
  const [data, setData] = useState<ProcessedData>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const { language } = useLanguage();

  // نقشه‌برداری موضوعات CSV به نام‌های فارسی موجود در اپ
  const subjectMapping: SubjectMapping = {
    'math': 'ریاضی',
    'mathematics': 'ریاضی',
    'ریاضی': 'ریاضی',
    'physics': 'فیزیک',
    'فیزیک': 'فیزیک',
    'chemistry': 'شیمی',
    'شیمی': 'شیمی',
    'biology': 'زیست‌شناسی',
    'زیست': 'زیست‌شناسی',
    'زیست‌شناسی': 'زیست‌شناسی',
    'computer': 'کامپیوتر',
    'computer_science': 'کامپیوتر',
    'کامپیوتر': 'کامپیوتر',
    'algebra': 'جبر',
    'جبر': 'جبر',
    'astronomy': 'المپیاد نجوم',
    'astronomy_olympiad': 'المپیاد نجوم',
    'المپیاد_نجوم': 'المپیاد نجوم',
    'المپیاد نجوم': 'المپیاد نجوم',
    'physics_olympiad': 'المپیاد فیزیک',
    'المپیاد_فیزیک': 'المپیاد فیزیک',
    'المپیاد فیزیک': 'المپیاد فیزیک',
    'math_olympiad': 'المپیاد ریاضی',
    'mathematics_olympiad': 'المپیاد ریاضی',
    'المپیاد_ریاضی': 'المپیاد ریاضی',
    'المپیاد ریاضی': 'المپیاد ریاضی',
    'computer_olympiad': 'المپیاد کامپیوتر',
    'المپیاد_کامپیوتر': 'المپیاد کامپیوتر',
    'المپیاد کامپیوتر': 'المپیاد کامپیوتر'
  };

  const fetchCSVData = async () => {
    setLoading(true);
    setError(null);

    try {
      // برای حل مشکل CORS، از پروکسی یا داده‌های نمونه استفاده می‌کنیم
      // در صورت عدم دسترسی به CSV، داده‌های نمونه لود می‌شود
      
      let csvText = '';
      
      try {
        // تلاش برای دریافت CSV از Google Sheets
        const csvUrl = 'https://docs.google.com/spreadsheets/d/15h2sEHTinULt6B4mdBMLGZpcGkNs0xAiFItKeHra3fs/export?format=csv&gid=0';
        const response = await fetch(csvUrl, {
          mode: 'cors',
          headers: {
            'Access-Control-Allow-Origin': '*'
          }
        });
        
        if (response.ok) {
          csvText = await response.text();
        } else {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
      } catch (fetchError) {
        console.warn('Could not fetch from Google Sheets, using sample data:', fetchError);
        
        // داده‌های نمونه در صورت عدم دسترسی به Google Sheets
        csvText = `file_id,file_name,subject
1BCD_physics_week1,Physics Week 1 Notes,فیزیک
1BCD_physics_week2,Physics Week 2 Notes,فیزیک
1BCD_math_week1,Math Week 1 Notes,ریاضی
1BCD_math_week2,Math Week 2 Notes,ریاضی
1BCD_chemistry_week1,Chemistry Week 1 Notes,شیمی
1BCD_biology_week1,Biology Week 1 Notes,زیست‌شناسی
1BCD_computer_week1,Computer Week 1 Notes,کامپیوتر
1BCD_algebra_week1,Algebra Week 1 Notes,جبر
1BCD_astro_week1,Astronomy Olympiad Week 1,المپیاد نجوم
1BCD_physics_olympiad_week1,Physics Olympiad Week 1,المپیاد فیزیک`;
      }
      
      const rows = csvText.split('\n').filter(row => row.trim());
      
      if (rows.length <= 1) {
        throw new Error('CSV file is empty or contains only headers');
      }

      // پردازش CSV با مدیریت بهتر کاما و نقل‌قول
      const processedData: ProcessedData = {};

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i].trim();
        if (!row) continue;
        
        // تجزیه CSV با مدیریت نقل‌قول
        const columns = parseCSVRow(row);
        
        if (columns.length >= 3) {
          const csvRow: CSVRow = {
            file_id: columns[0]?.trim() || '',
            file_name: columns[1]?.trim() || '',
            subject: columns[2]?.trim() || ''
          };

          // نقشه‌برداری موضوع به نام فارسی
          const mappedSubject = subjectMapping[csvRow.subject.toLowerCase()] || 
                               subjectMapping[csvRow.subject] || 
                               csvRow.subject;

          if (mappedSubject && csvRow.file_id) {
            if (!processedData[mappedSubject]) {
              processedData[mappedSubject] = [];
            }
            processedData[mappedSubject].push(csvRow);
          }
        }
      }

      setData(processedData);
      setLastUpdated(new Date());
      
      // اطلاع‌رسانی به والد در صورت وجود callback
      if (onDataLoaded) {
        onDataLoaded(processedData);
      }
      
    } catch (err) {
      console.error('Error processing CSV data:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  // تابع تجزیه CSV با مدیریت نقل‌قول
  const parseCSVRow = (row: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < row.length; i++) {
      const char = row[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current);
    return result.map(col => col.replace(/"/g, ''));
  };

  useEffect(() => {
    fetchCSVData();
  }, []);

  const generateDriveLinks = () => {
    const links: { [subject: string]: { [fileName: string]: string } } = {};
    
    Object.entries(data).forEach(([subject, files]) => {
      links[subject] = {};
      files.forEach(file => {
        if (file.file_id) {
          links[subject][file.file_name] = `https://drive.google.com/file/d/${file.file_id}/view`;
        }
      });
    });

    return links;
  };

  const exportData = () => {
    const driveLinks = generateDriveLinks();
    const exportData = {
      timestamp: new Date().toISOString(),
      subjects: data,
      driveLinks,
      stats: {
        totalSubjects: Object.keys(data).length,
        totalFiles: Object.values(data).reduce((sum, files) => sum + files.length, 0)
      }
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pink-vulture-csv-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const totalFiles = Object.values(data).reduce((sum, files) => sum + files.length, 0);
  const totalSubjects = Object.keys(data).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-primary" />
            {language === 'fa' ? 'مدیریت داده‌های CSV' : 'CSV Data Manager'}
          </CardTitle>
          <CardDescription>
            {language === 'fa' 
              ? 'خواندن و پردازش داده‌های جزوه‌ها از Google Sheets'
              : 'Reading and processing notebook data from Google Sheets'
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-4">
            <Button onClick={fetchCSVData} disabled={loading} className="flex items-center gap-2">
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              {language === 'fa' ? 'به‌روزرسانی داده‌ها' : 'Refresh Data'}
            </Button>
            
            {totalFiles > 0 && (
              <Button onClick={exportData} variant="outline" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                {language === 'fa' ? 'خروجی JSON' : 'Export JSON'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Status Display */}
      <CSVStatusDisplay
        isLoading={loading}
        error={error}
        dataCount={totalFiles}
        subjectCount={totalSubjects}
        lastUpdated={lastUpdated}
        onRetry={fetchCSVData}
      />

      {totalSubjects > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>
              {language === 'fa' ? 'توزیع فایل‌ها بر اساس موضوع' : 'Files Distribution by Subject'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(data).map(([subject, files]) => (
                <div 
                  key={subject} 
                  className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => onSubjectSelect && onSubjectSelect(subject, data)}
                >
                  <div className="flex items-center gap-3">
                    <h4 className="font-medium">{subject}</h4>
                    <Badge variant="secondary">
                      {files.length} {language === 'fa' ? 'فایل' : 'files'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm text-muted-foreground">
                      {files.slice(0, 3).map(file => file.file_name).join(', ')}
                      {files.length > 3 && ` +${files.length - 3} ${language === 'fa' ? 'مورد دیگر' : 'more'}`}
                    </div>
                    {onSubjectSelect && (
                      <Button size="sm" variant="outline">
                        {language === 'fa' ? 'مشاهده' : 'View'}
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* راهنمای استفاده */}
      <CSVGuide />
    </div>
  );
}