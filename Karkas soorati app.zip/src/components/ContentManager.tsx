import { useState } from 'react';
import { useLanguage } from './LanguageProvider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Settings, Plus, Save, BarChart3, BookOpen, Users } from 'lucide-react';
import { contentConfig, updateAvailableNotebooks, getOverallStats, ContentStatus } from '../data/contentConfig';

export function ContentManager() {
  const { language, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<string | null>(null);
  const [tempConfig, setTempConfig] = useState<ContentStatus | null>(null);

  const stats = getOverallStats();

  const handleEditSubject = (subjectName: string) => {
    setEditingSubject(subjectName);
    setTempConfig({ ...contentConfig[subjectName] });
  };

  const handleSaveSubject = () => {
    if (editingSubject && tempConfig) {
      contentConfig[editingSubject] = { ...tempConfig };
      setEditingSubject(null);
      setTempConfig(null);
      // در محیط واقعی، اینجا باید به سرور ارسال شود
      console.log('✅ Subject updated:', editingSubject, tempConfig);
    }
  };

  const handleCancelEdit = () => {
    setEditingSubject(null);
    setTempConfig(null);
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          size="sm"
          className="gap-2 shadow-lg"
        >
          <Settings className="h-4 w-4" />
          {language === 'fa' ? 'مدیریت محتوا' : 'Content Manager'}
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-background rounded-lg max-w-4xl w-full max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              <h2>{language === 'fa' ? 'مدیریت محتوا' : 'Content Management'}</h2>
            </div>
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              {language === 'fa' ? 'بستن' : 'Close'}
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="p-6 border-b">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <BookOpen className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-medium">{stats.enabledSubjects}</div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'دروس فعال' : 'Active Subjects'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 mx-auto mb-2 text-green-500" />
                <div className="text-2xl font-medium">{stats.totalNotebooks}</div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'جزوه موجود' : 'Available Notebooks'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <BarChart3 className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                <div className="text-2xl font-medium">{stats.completion}%</div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'تکمیل شده' : 'Completion'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Plus className="h-8 w-8 mx-auto mb-2 text-orange-500" />
                <div className="text-2xl font-medium">{stats.disabledSubjects}</div>
                <div className="text-sm text-muted-foreground">
                  {language === 'fa' ? 'در انتظار' : 'Coming Soon'}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Subjects List */}
        <div className="p-6">
          <h3 className="mb-4">{language === 'fa' ? 'مدیریت دروس' : 'Manage Subjects'}</h3>
          
          <div className="space-y-4">
            {Object.entries(contentConfig).map(([subjectName, config]) => (
              <Card key={subjectName}>
                <CardContent className="p-4">
                  {editingSubject === subjectName ? (
                    // Edit Mode
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{subjectName}</h4>
                        <div className="flex items-center gap-2">
                          <Button size="sm" onClick={handleSaveSubject}>
                            <Save className="h-4 w-4 mr-2" />
                            {language === 'fa' ? 'ذخیره' : 'Save'}
                          </Button>
                          <Button size="sm" variant="outline" onClick={handleCancelEdit}>
                            {language === 'fa' ? 'لغو' : 'Cancel'}
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={tempConfig?.enabled || false}
                            onCheckedChange={(enabled) => 
                              setTempConfig(prev => prev ? { ...prev, enabled } : null)
                            }
                          />
                          <label>{language === 'fa' ? 'فعال' : 'Enabled'}</label>
                        </div>

                        <div>
                          <label className="text-sm">
                            {language === 'fa' ? 'تعداد جزوه موجود' : 'Available Notebooks'}
                          </label>
                          <Input
                            type="number"
                            min="0"
                            max="35"
                            value={tempConfig?.availableNotebooks || 0}
                            onChange={(e) => 
                              setTempConfig(prev => prev ? { 
                                ...prev, 
                                availableNotebooks: parseInt(e.target.value) || 0 
                              } : null)
                            }
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm">
                          {language === 'fa' ? 'پیغام سفارشی (فارسی)' : 'Custom Message (Persian)'}
                        </label>
                        <Textarea
                          value={tempConfig?.customMessage?.fa || ''}
                          onChange={(e) => 
                            setTempConfig(prev => prev ? {
                              ...prev,
                              customMessage: {
                                fa: e.target.value,
                                en: prev.customMessage?.en || ''
                              }
                            } : null)
                          }
                          placeholder="پیغام برای کاربران فارسی..."
                        />
                      </div>

                      <div>
                        <label className="text-sm">
                          {language === 'fa' ? 'پیغام سفارشی (انگلیسی)' : 'Custom Message (English)'}
                        </label>
                        <Textarea
                          value={tempConfig?.customMessage?.en || ''}
                          onChange={(e) => 
                            setTempConfig(prev => prev ? {
                              ...prev,
                              customMessage: {
                                fa: prev.customMessage?.fa || '',
                                en: e.target.value
                              }
                            } : null)
                          }
                          placeholder="Message for English users..."
                        />
                      </div>
                    </div>
                  ) : (
                    // View Mode
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <h4 className="font-medium">{subjectName}</h4>
                        <div className="flex items-center gap-2">
                          <Badge variant={config.enabled ? "default" : "secondary"}>
                            {config.enabled 
                              ? (language === 'fa' ? 'فعال' : 'Active')
                              : (language === 'fa' ? 'غیرفعال' : 'Disabled')
                            }
                          </Badge>
                          <Badge variant="outline">
                            {config.availableNotebooks}/35
                          </Badge>
                        </div>
                      </div>

                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleEditSubject(subjectName)}
                      >
                        {language === 'fa' ? 'ویرایش' : 'Edit'}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="p-6 border-t bg-muted/20">
          <h3 className="mb-4">{language === 'fa' ? 'عملیات سریع' : 'Quick Actions'}</h3>
          <div className="flex gap-2 flex-wrap">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => {
                // فعال کردن همه دروس
                Object.keys(contentConfig).forEach(subject => {
                  contentConfig[subject].enabled = true;
                });
                console.log('✅ All subjects enabled');
              }}
            >
              {language === 'fa' ? 'فعال کردن همه' : 'Enable All'}
            </Button>

            <Button 
              size="sm" 
              variant="outline"
              onClick={() => {
                // اضافه کردن یک جزوه به همه دروس فعال
                Object.entries(contentConfig).forEach(([subject, config]) => {
                  if (config.enabled && config.availableNotebooks < 35) {
                    config.availableNotebooks++;
                  }
                });
                console.log('✅ Added one notebook to all active subjects');
              }}
            >
              {language === 'fa' ? 'افزودن جزوه به همه' : 'Add Notebook to All'}
            </Button>
            
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => {
                // Export config
                const dataStr = JSON.stringify(contentConfig, null, 2);
                const dataBlob = new Blob([dataStr], {type:'application/json'});
                const url = URL.createObjectURL(dataBlob);
                const link = document.createElement('a');
                link.href = url;
                link.download = 'content-config.json';
                link.click();
              }}
            >
              {language === 'fa' ? 'صدور تنظیمات' : 'Export Config'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}